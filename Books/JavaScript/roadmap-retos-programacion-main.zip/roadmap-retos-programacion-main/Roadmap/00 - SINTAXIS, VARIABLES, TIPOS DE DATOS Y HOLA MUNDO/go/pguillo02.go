package main
/*
Comentario de bloque: https://go.dev/
*/

//Comentario de línea

import "fmt"

const constante = 10 

var integer int = 1
var float float32 = 3.14
var complejo complex64 = 1 + 2i
var byte byte = 'A'
var booleano bool = true
var cadena string = "Hola Go"
var simbolo rune = '±'


func main()  {
	fmt.Println(cadena)	
}