// Este es un comentario de una linea

/*
Este es un
comentario
en varias
lineas
*/

#include <stdio.h>


int main(){
    // variable
    int a = 7;

    //constante
    const int e= 9;
    
    //tipos de datos primitivos
    char letter = 'a';
    int entero = 9;
    float decimal = 1.5;
    double decimalDoble = -2456.4452;
    long enterolargo = 123344546L;
    short enterocorto= 128;
    unsigned enteroSinSigno = 10;
    unsigned long enteroSinSignoLargo = 451345245UL;
    unsigned short enteroSinSignoCorto = 256;

    //impresion por consola
    char lenguaje = 'C';
    printf("Hola, %c!\n", lenguaje);
    return 0;

}
