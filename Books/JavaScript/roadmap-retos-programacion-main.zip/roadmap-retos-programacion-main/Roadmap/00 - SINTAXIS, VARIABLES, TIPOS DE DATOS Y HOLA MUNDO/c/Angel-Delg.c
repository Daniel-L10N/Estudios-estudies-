#include <stdio.h>
#include <stdbool.h>

// Constante Simbolica o Directriz
#define CONSTANTE 2024

// Puedes encontrar mas información a traves de estos enlaces
// URL = https://www.w3schools.com/c/index.php
/*
   Comentario de varias lineas.
   URL = https://www.w3schools.com/c/index.php
*/

int main(void){
   int Variable = 2024;
   const int CurrentYear = 2024;

   // Tipos de datos
   char String[10] = "String";
   char Caracter = 'A';
   int Entero = 2024;
   double FlotanteDeMayorPresicion = 20.24;
   
   // Mensaje por consola.
   printf("Hola Lenguaje C.");

   return 0;
}