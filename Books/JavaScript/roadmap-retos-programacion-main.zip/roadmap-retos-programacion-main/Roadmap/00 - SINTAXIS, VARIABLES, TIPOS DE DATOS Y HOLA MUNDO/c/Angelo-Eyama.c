//Documentacion de C: https://devdocs.io/c/

//Comentario de una linea

/*
    Comentario
    de
    varias
    lineas
*/

//Librerias (necesarias para todo)
#include<stdio.h>;
#include<stdlib.h>;
#include<stdbool.h>

#define CONSTANTE 8

int numero = 10;
char caracter = 'a';
float decimal = 1.3;

int main(){
    printf("Hola, C");
    return 0;
}