/**
 * Sitio oficial de C
 * https://www.open-std.org/jtc1/sc22/wg14/
*/

// Esto es un comentario de una linea 

/*
Esto es un comentario de varias lineas
*/
#include <stdio.h>

int main()
{
    //Una constante
    const int constante = 5;
    
    //Una cadena
    char cadena[] = "C";
    
    //Tipos primitivos
    char caracter;
    short entero_pequeño;
    int entero;
    long entero_grade;
    float racional;
    double racional_d;

    //Impresion en Consola
    printf("¡Hola, %s !\n", cadena);
}
