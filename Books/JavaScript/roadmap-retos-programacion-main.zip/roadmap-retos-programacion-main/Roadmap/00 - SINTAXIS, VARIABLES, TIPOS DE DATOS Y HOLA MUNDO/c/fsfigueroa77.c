// https://www.open-std.org/jtc1/sc22/wg14/

// Comentario en una linea

/*
Comentario
en
varias
lineas
xd
*/

#include <stdio.h>
#define MI_CONSTANTE 0 // Creacion de constante

int main(){
    int mi_variable = 1; // Creacion de variable

    // variables con cada tipo de dato primitivo
    int tipo_entero = 1;
    float tipo_flotante = 1.1;
    char tipo_caracter[] = "hola";

    // hacer impresion de texto
    printf("Hola, C!");

    return(0);
}