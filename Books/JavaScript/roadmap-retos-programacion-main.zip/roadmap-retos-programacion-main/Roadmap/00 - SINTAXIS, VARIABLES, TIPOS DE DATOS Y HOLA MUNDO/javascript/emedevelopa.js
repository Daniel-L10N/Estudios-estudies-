//SITIO OFICIAL JAVASCRIPT
// https://ecma-international.org/

//TIPOS DE COMENTARIOS
// Comentario de una línea
/* Comentario
de varias
lineas*/

//VARIABLE Y CONSTANTE
let manos = 2;
const color = "azul";

//TIPOS DE DATOS PRIMITIVOS
//Number
let age = 17;

//String
let name = "Maria";

//Boolean
let cieloAzul = true;
let cieloVerde = false;

//Null
let country = null;

//Undefined
let age;


console.log("Hola, Javascript!");
