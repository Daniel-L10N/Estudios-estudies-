// https://www.javascript.com/

// Primer commentario
/* Segundo comentario */

var x = 1
var y= "¡Hola, Javascript!"
var z = true
var a = null
var b
var c = 10000n
var d = Symbol()
var e = Function()

const f = 3.14

console.log("los tipos de variables que hay en JS son: \n" 
                + typeof x + ", " + typeof y + ", " + typeof z + ", " + typeof a + ", " + typeof b + ", " 
                + typeof c + ", " + typeof d + ", " + typeof e)

console.log("\nUn ejemplo de una constante es el número pi que se aproxima a " + f + "\n")

console.log(y);



