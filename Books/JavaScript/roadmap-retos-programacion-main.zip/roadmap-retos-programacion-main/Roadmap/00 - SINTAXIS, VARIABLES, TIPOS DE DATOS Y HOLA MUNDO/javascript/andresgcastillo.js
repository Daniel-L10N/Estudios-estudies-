// #00 SINTAXIS, VARIABLES, TIPOS DE DATOS Y HOLA MUNDO
//https://www.javascript.com/

// Comentario de una linea

/*
    Comentario
    de
    varias
    lineas

*/

let variable = "Hola Mundo!";
const constant = "Hello Mundo!";

let number = 23;
let bigint = 9876543219876543210;
let string = "hello";
let boolean = false;
let decimal = 3.14;
var undefinedValue = undefined;
let symbol = symbol("nuevoSimbolo");

console.log("¡Hola Javascript!");
