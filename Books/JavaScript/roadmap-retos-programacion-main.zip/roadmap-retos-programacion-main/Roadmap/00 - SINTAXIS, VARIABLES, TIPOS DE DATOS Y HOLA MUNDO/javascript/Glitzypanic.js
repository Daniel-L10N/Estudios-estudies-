// https://developer.mozilla.org/en-US/docs/Learn/Getting_started_with_the_web/JavaScript_basics sitio no oficial

// Esta es una forma de comentar en JavaScript en una linea

/* 
    Esta es otra forma de comentar en JavaScript
    en mas de una linea
*/

var nombre = "José"; // Declaración de una variable

const apellido = "Farías"; // Declaración de una constante

var edad = 25; // Number
var nombre = "José"; // String
var estudiante = false; // Boolean
var vacio = null; // Null
var indefinido = undefined; // Undefined
var array = [1, 2, 3, 4, 5]; // Array
var objeto = {
  nombre: "José",
  edad: 25,
}; // Object

console.log("!Hola, JavaScript!");
