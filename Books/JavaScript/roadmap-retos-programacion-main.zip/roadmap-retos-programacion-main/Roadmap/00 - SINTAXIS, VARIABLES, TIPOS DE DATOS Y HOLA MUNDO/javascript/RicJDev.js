//EJERCICIO
//https://developer.mozilla.org/es/docs/Web/JavaScript
//comentario en una linea

/*
:D
comentario en varias lineas
*/

let myAge = 21;
const myName = 'Ricardo';
const myStr = 'Esta es una string';
const myInt = 3;
const myFloat = 3.45;
const myBool = true;
const myUndefined = undefined;

console.log('Hola, JavaScript');
console.log(`Tengo ${myAge} años`);
console.log(`Mi nombre es ${myName}`);
console.log(`${myFloat} es un number`)