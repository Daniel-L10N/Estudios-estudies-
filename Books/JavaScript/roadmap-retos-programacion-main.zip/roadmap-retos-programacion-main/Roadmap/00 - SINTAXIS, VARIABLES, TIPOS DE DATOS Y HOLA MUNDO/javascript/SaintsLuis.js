// https://developer.mozilla.org/es/docs/Web/JavaScript

// Comentario de una linea
/* Comentario de 
varias lineas 
*/

const const1 = 1
var var1 = 1
let var2

const stringType = 'JavaScript'
const intType = 1
const boolType = true
const nullType = null
const undefinedType = undefined

console.log(`¡Hola, ${stringType}`)
