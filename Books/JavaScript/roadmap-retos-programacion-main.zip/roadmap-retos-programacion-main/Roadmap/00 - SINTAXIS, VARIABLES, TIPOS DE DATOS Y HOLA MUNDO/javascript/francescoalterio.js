/* Javascript no cuenta con un sitio oficial pero podemos encontrar una gran documentacion en: 
https://developer.mozilla.org/en-US/docs/Web/JavaScript */

// Comentario de una linea
/* Comentario de varias lineas */

let varaible = 20;
const CONSTANTE = "Hola Mundo";

// Tipos de datos primitivos
const MyString = "Hola Mundo";
const MyNumber = 20;
const MyBoolean = true;
const MyBigInt = BigInt("1234567890123454756564968684");
const MyNull = null;
const MyUndefined = undefined;
const MySymbol = Symbol("Hola Mundo");

console.log("Hola, Javascript");
