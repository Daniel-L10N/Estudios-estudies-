// https://www.javascript.com/

//Comentario en una linea es de esta forma

/*
Comentarios en multilinea se
hace de 
esta otra forma
*/

// tipos de variables
var variable = "Variable en Javascript";
const varibaleCostante = "Variable constante";

//tipos de datos
const string = "texto";
const numeroEntero = 200;
const numeroDecimal = 1.09;
const boleano = true;

//imprimir
console.log("Hola, Javascript");
