// link de la documentacion oficial de Javascript https://developer.mozilla.org/es/docs/Web/JavaScript

// este es un comentario de una sola linea

/* este 
es
un
comentario
de
varias
lineas
*/

let nombre = "Matias";
const apellido = "Nuñez";

let string = "Cadena de texto"; // cadena de texto
let numero = 10; // entero
let booleano = true; // booleano
let flotante = 10.5; // flotante
let nulo = null; // nulo
let indefinido; // udefined

console.log("Hola, Javascript!");

