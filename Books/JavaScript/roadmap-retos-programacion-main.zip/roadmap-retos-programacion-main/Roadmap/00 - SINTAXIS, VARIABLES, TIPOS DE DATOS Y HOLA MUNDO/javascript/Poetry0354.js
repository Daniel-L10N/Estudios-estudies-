//https://www.javascript.com/ O https://developer.mozilla.org/en-US/docs/Web/JavaScript

/* 
Hola Como estamos?
Este es un coomentario en varias lineas, algo que realmente no sabia
Hasta este momento jssjsjs 
Pero bueno :D
*/
let adios = "Hasta luego";
const bueno = "Hola";
var viejito = "edad";

 //Tipos de datos en JavaScript (Segun el curso que hice del ministerio de educacion :D).
 /* 
 Encontramos los datos esenciales.
 - Number
 - String
 - Boolean
 - Undefined
 - Null
 - Object
 - Symbol
 */
let Number = 10; //Cualquier tipo de Numero incluyendo los decimales.
let String = "Hola Comunidad" //Cualquier tipo de texto que debe estar entre comillas.
let Boolean = true; //Cualquier tipo de booleano. Verdadero o Falso.
let Undefined; //Variable declara pero que no tiene un valor asignado por ahora.
let Null = null;//Variable que no tiene valor.
let Object = {
    nombre: "Diego",
    edad: 20,
    estatura: 1.70
};//Objeto que contiene varios datos. Atributos.

console.log("Hola, JavaScript, ¿Como estamos?");