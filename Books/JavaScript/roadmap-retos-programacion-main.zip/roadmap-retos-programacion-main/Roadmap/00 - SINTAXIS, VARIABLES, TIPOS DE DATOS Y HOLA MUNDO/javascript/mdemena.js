//https://developer.mozilla.org/es/docs/Web/JavaScript

// Solo una linea

/*
Bloque de comenatrios
Para que sea más fácil
*/

let language = "Javascript";
const CONSTANT = "CONSTANTE";

let varNumber = 0;
let varBigInt = 9007199254740991;
let varString = "STRING";
let varBoolean = true;
let varNull = null;
let varUndefined = undefined;
let varSymbol = Symbol(language);

console.log("¡Hola, " + language + "!");