// Voy a Retomar la programación con el lenguaje JavasCript espero todo vaya bien
// https://developer.mozilla.org/es/docs/Web/JavaScript

// Comentario una linea

/*
    ##
    ## Para varias lineas
    ##
*/

const pi = "3.14"
let saludo = "Hola"
let lenguaje = "Javascript"

// Tipo de datos primitivos
// Number
let num = 100;
let floating = 100.5;

// boolean
let isActive    = true;
let isNotActive = false;

//string
let nombre = "Omar"
let nombreCompleto = "Omar Jesús Landaeta"

//undefined 
let anything = undefined;

//null
let fname = null;

console.log(`¡Hola, ${lenguaje}!`);