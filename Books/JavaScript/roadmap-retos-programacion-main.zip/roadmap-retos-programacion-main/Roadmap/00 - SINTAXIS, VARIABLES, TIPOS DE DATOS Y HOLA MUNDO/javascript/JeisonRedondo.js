// Hola soy Jeison Redondo y este es un comentario de una linea, la url de Javascript es :https://www.javascript.com/

/*
Este es un comentario que puede 
manejar varias lineas
*/

// Javascript y sus variables

var estaEsUnaVariable = false; //Aunque no recomendada, esta es una forma de definir una variable

let estaEsOtraVariable = true; //Esta es hoy en dia la recomendación a la hora de definir una variable dinamica.

const laReinaDeJS = "Hola como estan"; // Si esta es la variable constante de JS

// Javascript - Datos Primitivos

let numerosNormales = 21;

// Estos dos numeros son la forma de manejar numeros muy grandes en JS
let numerosGrandes = BigInt(234934823984);

let otroNumeroGrande = 23894284729374823748937n;

const cadenasDeTexto = "Esto es una cadena de texto";

const otraCadenaDeTexto = "Tambien podemos hacerlas con estas comillas";

let unaCadenaMuyEspecial = `Con estas comillas podemos incluir ${"varia" + "bles"}`;

let soyFalso = false;

const soyVerdadero = true;

let soyNull = null;

const estoyUndefined = undefined;

let noSoyUnNumero = NaN;

console.log("¡Hola, estoy estudiando Javascript");
