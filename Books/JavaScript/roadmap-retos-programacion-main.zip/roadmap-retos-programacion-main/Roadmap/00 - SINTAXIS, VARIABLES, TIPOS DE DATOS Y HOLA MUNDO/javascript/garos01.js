// Este es un comentario en una línea.
//Visita el sitio oficial de JavaScript en: https://developer.mozilla.org/es/docs/Web/JavaScript

/*
Este es un comentario multilinea.
Puedes usar /* para iniciar y 
*/

// Creación de una variable y una constante
let miVariable = 10;
const MI_CONSTANTE = "Hola";

// Variables representando tipos de datos primitivos
let cadenaTexto = "JavaScript!";
let entero = 42;
let flotante = 3.14;
let booleano = true;

// Imprimir por terminal el texto
console.log(`¡Hola, ${cadenaTexto}`);
