// https://developer.mozilla.org/es/docs/Web/JavaScript

//esta es una forma de comentar.

/** esta es una forma de 
*comentar en varias 
*lineas
*/

/*esta es otra forma
de comentar en
varias linea*/

let numero = 30;
const nombre = 'jaxi';

let string = 'string';
let number = 11;
let boolean = true;
let boolean2 = false;
let undefined;
let nulo = null
let simbolo = symbol('yo');
let bigint = 6537468565046484688575n;

console.log('¡hola, JavaScript!');
