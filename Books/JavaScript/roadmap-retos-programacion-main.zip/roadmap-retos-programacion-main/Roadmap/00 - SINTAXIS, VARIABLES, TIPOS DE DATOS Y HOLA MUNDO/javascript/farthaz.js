/* https://developer.mozilla.org/en-US/docs/Web/JavaScript este no es el sitio oficial de JS
segun internet, no posee un sitio como tal y esta es la principal fuente de consulta (documeentacion*/

// Variables
var number = 20//este valor puede cambiar y solo se utiliza en navegadores viejos
let value = BigInt("1234567890123454756564968684")
let money = null

const text = "JavaScript" //constantes, no pueden cambiar
const question = true
const fruits = ["bananas", "apples", "pears"]
const employeeId = {firstName: "Alicia", lastName: "Gomez", ID: "1566", department:"IT", shift: "Fixed"}
const d = new Date()

console.log("Hola,", text)