// https://www.javascript.com/

// Hello World
/* Hello World */

let a = 'Hello';
var b = 'Hello';

const pi = 3.1416;

let name = "Alice";
let isLoggedIn = true;
let declaredVariable;       //undefined
let emptyObject = null; 
let largeNumber = 9007199254740991n;

let language  = 'JavaScript';

console.log('Hello',language);

