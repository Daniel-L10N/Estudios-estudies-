/* https://developer.mozilla.org/es/ */

/* comentario de una linea */

/*Un comentario
que se extiende
en varias
líneas*/
/* Tipos De Variables */
var name1 = 317 ;

let  name2 = 519; 

const Pi = 3.1419;

/* Datos Primitivos */
var texto = "tpm";
var number = 0 ;
var granentero = 556n ;
var y = false ; /*boolean true or false*/
var x ;
let sym1 = Symbol("simbolo");

var nulo = null ;
/*Imprimir por Terminal El nombre de tu lenguaje*/
var lenguaje = "¡Hola, JavaScript!";
console.log (lenguaje)
