// El url del sitio web oficial de JavaScript: https://developer.mozilla.org/es/docs/Web/JavaScript

// Comentario en linea

/*
Comentario
en
varias
lineas
*/

var miNombre = "Marcos";
let miSegundoNombre = "Pedro";
const miApellido = "Lombardo";

let string = "JavaScript";
let number = 8;
let boolean = true;
let indefinido = undefined;
let nulo = null;

console.log(`¡Hola, ${string}!`);
