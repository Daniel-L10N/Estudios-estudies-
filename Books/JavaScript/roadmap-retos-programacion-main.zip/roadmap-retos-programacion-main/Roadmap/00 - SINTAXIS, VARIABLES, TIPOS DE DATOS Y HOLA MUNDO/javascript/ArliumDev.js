// URL = https://developer.mozilla.org/es/docs/Web/JavaScript

// Esto es un comentario en una línea

/* Esto es un comentario
en varias líneas */

let variable = "Variable";
const constante = "Constante";

let cadenaTexto = "Soy una cadena de texto";
let num = 22;
let bigInt = 123456789012345678901234567890;
let boolean = true;
let undef = undefined;
let nul = null;
let symbol = Symbol("simbolo");

console.log("¡Hola, Javascript!");

