'use strict'

//"https://developer.mozilla.org/es/docs/Web/JavaScript"

// Esto es un comentario de una sola linea

/**Esto es un comentrio
 * multilinea
 * en JavaScript 
 */

let miPrimeraVariable = "Hola Mundo"
const miPrimeraConstante = "Hola Mundo"

let integer = 10;
let float = 10.10;
let string = "Hola Brais Moure";
let bool = true;
let array = [10, 'Bob', true, 10.10];
let object = document.querySelector('h1');

console.log("¡Hola, JavaScript!")



