// URL del sitio web oficial de JavaScript: https://developer.mozilla.org/es/docs/Web/JavaScript

// Este es un comentario en línea

/* Y esta es la manera 
en la que se hacen comentarios 
en varias líneas */

// Creación de variable y constante

let variable = "variable"
var variable2 = "variable 2"
const constante = "constante"

// Variables representando los tipos de datos primitivos

let cadenaTexto = "Cadena de texto"
let entero = 0
let booleano = true
let nulo = null
let indefinido = undefined


// Imprimir por terminal

console.log("¡Hola, JavaScript!");