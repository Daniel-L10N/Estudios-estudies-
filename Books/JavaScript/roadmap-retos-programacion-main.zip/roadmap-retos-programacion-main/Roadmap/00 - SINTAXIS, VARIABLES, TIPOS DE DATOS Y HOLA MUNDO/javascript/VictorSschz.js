//www.javascript.com
/**Esta es una manera
 * de representar comentarios en varias lineas
 */

const num= 1;
let num2 = 2;
let decimal = 5.5;
const verdadero = true;
const falso = false;
let indefinido;
const sinValor = null;
let noDef= NaN;

console.log('Hola, Javascript')