// https://developer.mozilla.org/es/docs/Web/JavaScript es la web oficial de JavaScript

// Comentario en una sola linea
/*
Este es un comentario
en varias lineas
en JavaScript 
*/
var variableVar = 'esta es una forma que no es recomendable usar';
let myVariable = 'esta es una variable en JavaScript';
const myConstante = 'Esta es una constante en JS';

let myInt = 1; // soy un entero
let myFloat = 1.5; // soy una variable float
let myString = 'soy un dato string'; 
let myBoolean = true; // tambien puedo ser false
let myUndefined = undefined; // soy una variable no definida
let myNull = null; // tambien soy una variable nula
let myBigInt = 9007199254740991n // tambien puedo ser un numero grande
let mySimbol = Symbol('kunfu') /// soy unico e inmutable

let myLenjuage = 'JavaScript'
console.log(`¡Hola, ${myLenjuage}`);