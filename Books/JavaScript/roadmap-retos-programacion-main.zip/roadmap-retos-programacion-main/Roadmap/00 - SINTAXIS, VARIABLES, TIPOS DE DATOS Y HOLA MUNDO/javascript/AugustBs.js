// https://developer.mozilla.org/es/docs/Web/JavaScript

// Comentario de una sola línea

/* Comentario 
de 
varias 
líneas */

let nombre = "Mi nombre";
const PI = 3.1416;

let numero = 10;
let decimal = 10.5;
let booleano = true;

console.log("Hola Mundo");
console.log(nombre);
console.log(numero);
console.log(decimal);
console.log(booleano);