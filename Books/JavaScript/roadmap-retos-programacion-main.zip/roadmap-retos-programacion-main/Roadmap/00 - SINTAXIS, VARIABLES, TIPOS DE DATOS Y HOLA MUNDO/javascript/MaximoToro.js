/*
URL WEB del lenguaje JavaScript
https://developer.mozilla.org/es/docs/Web/javascript
*/

//este es un comentario en linea

/*
estos son 

multiples 

comentarios 

*/

// variables 
let prueba; 

const pi = 3.14;

//Datos primitivos 

let texto = nombre;
let boolean = true; 
let undefinido = undefined; 
let edad = 10; 
let bigInt = 139012839012839012839028132190312n; 
let symbol = Symbol(); 

//imprimir 

console.log(" hola [Javascript] ");



