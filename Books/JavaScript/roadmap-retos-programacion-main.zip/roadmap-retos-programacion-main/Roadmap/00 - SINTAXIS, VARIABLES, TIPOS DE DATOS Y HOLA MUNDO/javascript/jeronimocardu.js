// https://www.javascript.com

/**
 * https://www.javascript.com
 */

/*
https://www.javascript.com
*/

let variableLet;
const variableConst = 0;

let string = 'Hola mundo!';
let number = 0;
let boolean = true;
let undefined = undefined;
let isNull = null;

console.log('¡Hola, JavaScript!')