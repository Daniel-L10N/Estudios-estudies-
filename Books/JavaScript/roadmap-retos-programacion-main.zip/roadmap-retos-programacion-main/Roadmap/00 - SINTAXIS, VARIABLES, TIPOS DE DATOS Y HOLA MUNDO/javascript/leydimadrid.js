/* Web Oficial de JavaScript:
URL: https://developer.mozilla.org/en-US/docs/Web/JavaScript */

//Comentario de una línea

/* Esto es un 
Comentario en varias lìneas*/

//Let y const
let myVariable = "Soy una variable con let";
const MYVARIABLE = "Soy una constante";

//Tipos de datos primitivos en JavaScript

let string = "Soy un String";
let number = 10;
let booleanTrue = true;
let booleanFalse = false;
let nullType = null;
let undefined;
let symbol = Symbol("Soy un Symbol");
let Bignit = 100000000000000000000;

//Imprimir en la consola
console.log("¡Hola, JavaScript");
