/* https://developer.mozilla.org/es/docs/Web/JavaScript */

/* Sintaxis 
  en dos lineas */

/*********************
Otra sintaxis
**********************/

let nombre = 'JavaScript';
const edad = 25;

let isTrue = true;
let nulo = null;
let nodefinido = undefined;

console.log(`Hola, ${nombre}`);
