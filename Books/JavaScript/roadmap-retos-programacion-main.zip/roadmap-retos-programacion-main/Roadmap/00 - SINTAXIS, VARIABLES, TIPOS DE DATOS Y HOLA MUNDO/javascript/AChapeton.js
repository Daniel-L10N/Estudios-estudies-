// Sitio web oficial: https://developer.mozilla.org/es/docs/Web/JavaScript

// Comentario de una linea

/* Comentario
en multiples
lineas */

var languageName = 'JavaScript';
var stringType = 'string';
var numberType = 10;
var booleanType = true;
var nullType = null;
var undefinedType = undefined;
console.log("Hola " + languageName + "!");