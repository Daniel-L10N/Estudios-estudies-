//https://developer.mozilla.org/es/docs/Web/JavaScript

//ESTO ES UN COMENTARIO DE UNA SOLA LINEA 

/*ESTO ES UN COMENTARIO
DE MULTIPLES LINEAS*/

let text = "esto es una variable";
const text2 = "esto es una constante";

// ESTO ES UNA VARIABLE TIPO TEXTO
let string = "Hola mundo";

// ESTO ES UNA VARIABLE TIPO NUMERO ENTERO
let numeroEntero = 50;

// ESTO ES UNA VARIABLE TIPO NUMERO FLOTANTE
let numeroFlotante = 5.14;

// ESTO ES UNA VARIABLE TIPO BOOLEANO
let verdadero = true;
let falso = false;

// ESTO ES UNA VARIABLE TIPO INDEFINIDO SE UTILIZA CUANDO NO QUIERES DEFINIR LA VARIABLE 
let undefined;

// ESTO ES UNA VARIABLE TIPO NULL SE UTILIZA PARA DEFINIR UNA VARIABLE PERO SIN NINGUN VALOR
let nulo = null;


// ESTO ES UNA VARIABLE TIPO Symbol
let idenficador = Symbol("descripcion");

// ESTO IMPRIMI UN MENSAJE EN CONSOLA
console.log('"¡Hola, JavaScript!"');
console.log(numeroEntero + numeroFlotante);