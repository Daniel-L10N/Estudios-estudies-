/**EJERCICIO:
 * - Crea un comentario en el código y coloca la URL del sitio web oficial del lenguaje de programación que has seleccionado.
      a-. Sitio web oficial de Java Script: https://developer.mozilla.org/es/docs/Web/JavaScript

 * - Representa las diferentes sintaxis que existen de crear comentarios en el lenguaje (en una línea, varias...).
 
      a.- //Soy un comentario de una linea
      
      b.- /**
            Soy un comentario multilinea
      **/
  /**      
  
   **/

// * - Crea una variable (y una constante si el lenguaje lo soporta).

//Variables:

      let My_Variable =0;
      var My_Var =10;

//Constante:

      const Myconstan =0;
      
 //* - Crea variables representando todos los tipos de datos primitivos del lenguaje (cadenas de texto, enteros, booleanos...).
    
    
      //NUll 
            let Null = null;

      //Undefined
            let Undefined = undefined;

      //Boleean- True && false

             let My_BoleeanT = true;
             let My_BoleeanF= false;

      //Number
            let My_Number = 14;

      //String
            let My_String = "i'm programmer";

      //Bigint
            let My_Bigint = 300n;

      //Symbol
            let sym1 = Symbol();
            let sym2 = Symbol("FOG");      

 // * - Imprime por terminal el texto: "¡Hola, [y el nombre de tu lenguaje]!"

console.log( "¡Hola, Java Script!");


