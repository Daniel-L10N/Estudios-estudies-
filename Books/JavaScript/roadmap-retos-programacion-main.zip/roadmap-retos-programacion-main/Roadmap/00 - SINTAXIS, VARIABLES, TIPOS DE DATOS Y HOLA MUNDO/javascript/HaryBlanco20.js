/*El lenguaje de programación que he seleccionado es JavaScript.
URL del sitio web oficial de JavaScript es https://developer.mozilla.org/es/docs/Web/JavaScript
*/

//Comentario de una línea

/*Comentatio de
varias
líneas*/

//variable
let miVariable = "variable";
const miConstante = "constante"


//Tipos de datos
let cadena ="Hola mundo"
let booleano = true
let entero = 567
let flotante = 1.43
let array = [1, "Hola", true]
let objeto = {
    nombre: "Hary",
    apellido: "Blanco",
    edad: 28
}
let arregloDeObjetos = [
    {
        nombre: "Hary",
        apellido: "Blanco",
        edad: 28
    },
    {
        nombre: "Pedro",
        apellido: "Blanco",
        edad: 56
    }
]

let lenguaje = javascript
console.log('"¡Hola, mi lenguaje es' + lenguaje + '!"')


