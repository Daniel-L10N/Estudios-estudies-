//Sitio web: https://developer.mozilla.org/es/docs/Web/JavaScript

//Comentario de una sola linea

/*Comentario
en multiples
lineas*/

let variable = "Hola";
const constante = "Mundo";

let numero = 1;
let cadena = "Hola mundo";
let booleano = true;
let indefinido = undefined;

console.log("Hola, JavaScript!");