//? URL: https://www.javascript.com/

/*
 !Fuentes de información:
?- https://www.javascript.com/
?- https://developer.mozilla.org/en-US/docs/Web/JavaScript
*/

var numero = 0;
let variable = 0;
const constante = 3.14;

// !Tipos de datos primitivos:
let string = "Cadena de texto";
let entero = 0;
let booleano = true;
let nulo = null;
let indefinido = undefined;

console.log("!Hola, JavaScript!");
