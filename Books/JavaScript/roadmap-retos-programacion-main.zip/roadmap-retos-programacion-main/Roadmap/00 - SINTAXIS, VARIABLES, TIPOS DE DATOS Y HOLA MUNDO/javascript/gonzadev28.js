/*Escribo un comentario añadiendo la URL oficial
del lenguaje de programacion seleccionado.
Web oficial de Javascript ----> https://www.javascript.com/ */

//Otro metodo de añadir un comentario

//Igualmente se puede comentar en varias lineas
//con éste metodo 

//Crear variables 

let variable1 = '';
const variable2 = '';

//Crear variables con tipo de datos primitivos

let texto = 'string';
let numero = 50;
let boolean = true;
let boolean2 = false;
let nulo = null;
let indefinido = undefined;

//Imprimir en el terminal 
console.log('Hola, Javascript!');