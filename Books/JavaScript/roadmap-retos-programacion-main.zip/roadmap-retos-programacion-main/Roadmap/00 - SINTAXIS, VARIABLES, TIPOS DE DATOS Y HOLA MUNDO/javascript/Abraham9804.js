//https://developer.mozilla.org/en-US/docs/Web/javascript

//Comentario en una linea 

/*Comentario 
en multiples 
lineas */

let num = 1
const pi = 3.1416

let entero = 1
let decimal = 1.5
let numeroGrande = 1234567890123456789n
let texto = "Hola mundo"
let booleano = true
let indefinido = undefined


console.log("¡Hola, Javascript!")