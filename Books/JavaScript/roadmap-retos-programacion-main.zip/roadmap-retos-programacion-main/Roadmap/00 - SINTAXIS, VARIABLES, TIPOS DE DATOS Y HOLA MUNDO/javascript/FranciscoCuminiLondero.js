// https://www.javascript.com/

// Comentario de una línea

/*
Comentario 
de varias 
líneas
*/

const MI_NOMBRE = "Francisco Cumini";
let edad = 23;

let myString = "Francisco";
let myNumber = 1;
let myBoolean = true;
let myNull = null;
let myUndefined = undefined;
let mySymbol = Symbol();
let myBigInt = BigInt(32);

console.log("¡Hola, JavaScript!");
