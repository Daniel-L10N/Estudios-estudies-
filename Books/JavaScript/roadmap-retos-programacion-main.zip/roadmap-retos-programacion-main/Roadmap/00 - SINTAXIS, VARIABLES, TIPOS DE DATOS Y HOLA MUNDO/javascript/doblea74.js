//web oficial https://developer.mozilla.org/en-US/docs/Web/JavaScript

//comentario en una linea

/* esto es un comentario
en varias lineas */

let unaVariable = 'esto es una variable'; 
const unaConstante = 'esto es una constante';

let numero = 0;
let boolean = true;
let string = 'esto es un string';
let array = [];
let varUndefined;
let BigInt = 131312316n;
let isNull = null;

let miLenguaje ='JavaScript'

console.log("¡Hola, " + miLenguaje + "!");