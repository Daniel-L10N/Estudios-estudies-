// JavaScript sitio oficial 
// https://developer.mozilla.org/es/docs/Web/JavaScript

// Como realizar comentarios:

// Con dos lineas diagonales podremos crear comentarios de una linea //

/* Tambien podemos crear comentarios 
de multiples lines solo debemos abrir el
comentario con barra inclinada asterisco 
/* y cerrarlo con asterisco barra inclinada */  

// Variables y constantes 
var name = jhon;
let number = 2;
const number2 = 5;

// Datos primitivos 

let string = 'Esto es un string', // String
let number = 25;   // Number
let boolean = true;  // Boolean
let nulo = null;  // Dull
let undefined;  // undefined
const uniqueId = Symbol('id'); // Symbol
let bigInt = 325214241214613246131215412; // BigInt

console.log("¡Hola, JavaScript");

