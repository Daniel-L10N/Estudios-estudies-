

// mi sitio web de javascrip: https://www.w3schools.com/js/js_objects.asp

// esto es un comentario de una sola linea 

/*
 esto es un comentario
de varias lineas de 
texto
*/

//  variables y constantes

var kevin = "kevin";
const x = 25;

// numbers:

let peso = 85;
let altura = 1.75; 

//string:

let color = "blanco";

//booleans:

let booleans = true;

//object:

const cars = {llantas: "invierno", nieve: "moderado"};

//array:

const caract = ["cuatroPuertas", "blanco", "bmw"];

console.log("hola, mi lenguaje es javascript");
