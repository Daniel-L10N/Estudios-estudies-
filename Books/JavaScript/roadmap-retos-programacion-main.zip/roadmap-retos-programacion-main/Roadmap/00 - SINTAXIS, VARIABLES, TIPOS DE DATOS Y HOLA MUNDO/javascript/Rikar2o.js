//El lenguaje mas chingon JavaScript https://www.javascript.com/

// comentario de una linea

/*
comentarios de varias
lineas o de parrafos
*/

//Crea una variable y una constante
let miVariable = "soy una variable";
const miConstante = "soy una constante";

//Crea variables representando todos los tipos de datos primitivos//

let numero = 12;
let string = "soy una cadena de texto";
let booleano = true;

//Imprime por terminal el texto: "¡Hola, [y el nombre de tu lenguaje]!"

let lenguajeProgramacion = "JavaScript";

console.log(`Hola ${lenguajeProgramacion}`);
