// WEB OFICIAL
// https://developer.mozilla.org/es/docs/Web/JavaScript

// COMENTARIOS

/**
* Comentarios de varias lineas
* Este es un tipo de comentario sirve para describir funcionalidades de metodos, clases, etc
*/
// Comentarios de una linea. Para comentarios breves

// Javascript
var name = "Ken";
let lastName = "Zambrano";
const PI = 3.1416;
let boolean = true;

console.log("Hola este es mi javascript!!! ", name + " " lastName);
