// URL sitio web oficial JavaScript: "https://developer.mozilla.org/es/"

// comentario en una sola linea

/* 
este es un comentario
multilinea 
*/

// variable y constante en JS

let variable = 1;
const constante = 2024;

// tipos de datos en JS

let number = 10;
let boolean = false;
let string = "JavaScript";
let array = [1, 2, 3, 5, 7, 11];
let objeto = {};

console.log("¡Hola, " + string + "!"); // Imprime por consola: "¡Hola, JavaScript!"
