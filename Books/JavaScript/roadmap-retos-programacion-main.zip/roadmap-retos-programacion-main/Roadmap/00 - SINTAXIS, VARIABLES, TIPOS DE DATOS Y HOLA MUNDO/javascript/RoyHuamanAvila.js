//https://developer.mozilla.org/en-US/docs/Web/javascript

//En Linea

/*
  Comentario
  Multiline 
*/

var variable;
const constante = 0;

let cadena = "String";
let numero = 2002;
let booleano = true;
let decimal = 2.2;
let array = [1, 2, 3, 4];
let objeto = {
  name: "Roy Andres",
  age: 22,
};
let nan = NaN;
let indefinido = undefined;
let nulo = null;
let symbol = Symbol("Symbol object");

const lenguaje = "Javascript";

console.log(`¡Hola, ${lenguaje}!`);
