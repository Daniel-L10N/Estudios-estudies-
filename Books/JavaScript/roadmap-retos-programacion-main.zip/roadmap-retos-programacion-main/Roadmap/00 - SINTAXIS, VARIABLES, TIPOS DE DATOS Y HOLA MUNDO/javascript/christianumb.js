// https://www.javascript.com/ 
// Comentarios de una sola línea
/* Comentarios de varias líneas
*/
let a = 10
const b = 5
let c = "Hola" //String
let d = 5 //Number
let e = true //Boleano
let f = null //Nulo
let g = undefined

console.log ("¡Hola, JavaScript!")

