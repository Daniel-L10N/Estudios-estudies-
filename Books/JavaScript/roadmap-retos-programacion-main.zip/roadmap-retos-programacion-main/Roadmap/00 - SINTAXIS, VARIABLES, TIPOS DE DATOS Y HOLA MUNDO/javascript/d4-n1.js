// Documentación oficial de JavaScript: https://developer.mozilla.org/en-US/docs/Web/javascript

// Esto es un comentario de una sola línea.

/*
Esto es un comentario de varias líneas de longitud.
*/

// Variables y constantes
const name = "d4-n1"
var oldSchoolVariable = "I'm the old way to write a variable"
let newVariable = "I'm the current way to write a variable"

// Primitives
let string = "string"
let number = 8
let boolean = true
let undefined

// Console.log
console.log("¡Hola, JavaScript!")