//https://www.javascript.com//

//Comentario de una sola línea//

/*
    Esto
    Es
    Un
    Comentario
    Multilinea
*/


var x = 5; //Variable llamada X con valor igual a 5//

const price = 20; //Variable constante llamada price con valor igual a 20//

let name = carlos; //string//
let age = 24; //int//
let sundistanceinmeters = 149597870700; //BigInt//
let boolean = false; //Booleano//
let imNull = null; //Null//
let sym1 = Symbol("simbolo1"); //Symbol//
let myundefined = undefined; //Undefined//

console.log("¡Hola, JavaScript!");