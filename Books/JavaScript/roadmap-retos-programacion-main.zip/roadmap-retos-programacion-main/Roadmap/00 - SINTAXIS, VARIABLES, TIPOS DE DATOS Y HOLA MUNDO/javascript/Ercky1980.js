// https://www.javascript.com/

//Comentario en una linea

/**Esto es comentario en
 * varias lineas con javascript
 */

/*
Comentario en varias lineas
sin el asterisco en cada una
 */

let myAge = "43";

const myName = "Erick E.";

let number = 10;
let decimal = 0.5;
let string = "SantaAna";
let otherString = 'SantaAna';
let verdadero = true;

console.log("Hola JavaScript");