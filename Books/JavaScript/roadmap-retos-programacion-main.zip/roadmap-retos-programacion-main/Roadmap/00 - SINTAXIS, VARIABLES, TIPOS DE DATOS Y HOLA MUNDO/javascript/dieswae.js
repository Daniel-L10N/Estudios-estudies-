// https://developer.mozilla.org/en-US/docs/Web/JavaScript

// Comentario de una linea

/*
  Comentario 
  de varias
  lineas
*/

let soyVariable = 'Soy una variable';
const soyConstante = 'Soy una constante';

let String = 'Soy una cadena de texto';
let Number = 10;
let Boolean = true;
let Boolean2 = false;
let undefined; // undefined
let undef = undefined;
let nulo = null

console.log('¡Hola, JavaScript!');


