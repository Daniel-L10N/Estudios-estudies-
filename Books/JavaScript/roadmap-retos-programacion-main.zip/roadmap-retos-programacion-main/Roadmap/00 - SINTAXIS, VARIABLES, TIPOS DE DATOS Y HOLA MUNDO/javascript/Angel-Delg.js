// URL = https://developer.mozilla.org/en-US/docs/Web/JavaScript
/*
   Comentarios de varias Lineas.
   URL = https://developer.mozilla.org/en-US/docs/Web/JavaScript
*/

let variable;
const constante = {}

// tipos de datos primitivos
let numerico = 2024
let cadenaTexto = "2024"
let isNewYear = true
let indefinido = undefined
let nulo = null

// Mensaje por consola
console.log("Hola Javascript")