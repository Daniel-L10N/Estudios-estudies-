// https://developer.mozilla.org/es/docs/Web/JavaScript
/* Comentario
con muchas
líneas */

var zzz;
const uno = undefined; // Indefinido

let dos = 'Hola'; // String
let tres = 3; // Entero
let cuatro = 4.0; // Float
let boolean = true; // Boolean
let a = null; // null

console.log("¡Hola, JavaScript!");
console.log(uno); // Para ejecutar el const inicializado y no causar errores xD.