// URL: https://developer.mozilla.org/es/docs/Web/JavaScript

// Comentario en una sola linea: por ejemplo ---- Section Header ----

// Comentario 
// en varias
// lineas de 
// codigo 

let nombre;

const tipoAnimal = "Pinguino";

let edad = 24;

let estaVivo = true;

let altura = 1.80;

let apellido = "Loodermin";

let fechaMuerte = undefined;

let cantCertificados = null;

console.log("¡Hola, JavaScript!");