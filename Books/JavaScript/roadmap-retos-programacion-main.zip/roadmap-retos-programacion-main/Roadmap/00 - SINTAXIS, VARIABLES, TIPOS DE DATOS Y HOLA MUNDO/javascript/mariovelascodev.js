//https://developer.mozilla.org/es/docs/Web/JavaScript

//Comentario en una línea
/*
    Comentatio en 
    varias líneas
 */

//Variable
let myVariable;
//Constante
const PI = 3.1415;

//Tipos primitivos
let variableStr = "Esto es un string";
let variableNumber = 3;
let variableBoolean = false;
let variableNull = null;
let variableUndefined = undefined;

console.log("¡Hola, Javascript!");