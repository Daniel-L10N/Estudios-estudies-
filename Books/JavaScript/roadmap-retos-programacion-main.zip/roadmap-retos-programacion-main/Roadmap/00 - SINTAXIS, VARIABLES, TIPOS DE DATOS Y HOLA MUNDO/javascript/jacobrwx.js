// https://developer.mozilla.org/en-US/docs/Web/JavaScript

// This is a Single-Line Comment.

/* This is a Multi-Line Comment. */

var varible1;
let variable2;

const VARIABLE_CONST = 11;

let num = 11;
let str = "Hello, World";
let bool = true;
let undef;
let n = null;
const SYM = Symbol("foo");

console.log("Hello, Javascript");