//?https://developer.mozilla.org/en-US/docs/Web/JavaScript

//* Comentario de una línea
/*
    Comentario de
    varias líneas
*/

let variable = 'Hola';
const constante = 'Mundo';

let name = 'David';
let age = 33;
let student = true;
let city = null;
let centimeterToTheMoon = 38440000000n;
let array = [1, 2, 3];
let objeto = {id: 1, name: 'david', email: 'davidhage@hotmail.com'};

console.log('Hola javascript!');
