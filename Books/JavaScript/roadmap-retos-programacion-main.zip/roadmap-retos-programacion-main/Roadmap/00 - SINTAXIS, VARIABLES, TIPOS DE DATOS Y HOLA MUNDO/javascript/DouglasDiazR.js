/*https://developer.mozilla.org/es/docs/Web/JavaScript*/

//Comentario en una sóla línea 

/*Comentarios
en
varias
líneas*/

var miVariable = "variable";
const miConstante = "constante";

var number = 5;
var string = "JavaScript";
var boolean = true;
var boolean = false;
var undefined = undefined;
var nulo = null;
var BigInt = 12324239583049683049683025436n; //Representa números enteros mayores que el rango seguro para el tipo Number. Se declara añadiendo una n al final del número literal.
console.log("hola " + string);
