// URL sitio web oficial JavaScript: "https://developer.mozilla.org/es/docs/Learn/JavaScript"
// Este es un comentario de una linea
/* 
Este es un comentario de muchas lineas
*/

// Variables y constantes en JS
let miNombre = "Gabriel";
const miApellido = "Alfaro";
var miEdad = 21;

// Tipos de datos en JS
let numero = 10;
let booleano = true;
let cadena = "JavaScript";
let array = [1, 2, 3, 4, 5];
let objeto = {};

console.log("¡Hola, " + cadena + "!"); // Imprime por consola: "¡Hola, JavaScript!"
console.log(`Hola mi nombre es ${miNombre} ${miApellido}`);
console.log(`Tengo ${miEdad} años`);
