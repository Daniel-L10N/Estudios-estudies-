//  https://www.javascript.com/

// comentario de una linea 
/**
 * comentario de varias lineas
*/
 
let myAge = 21;
const myName = 'josh'
let myNumber = 33;
let MyStrin = 'hola';
let falso = false;
let noDefinido;
let nulo = null; 


console.log('hola javascript');
console.log(`tengo ${myAge} anos`);
console.log(`mi nombre es ${myName}`);
console.log(`${myNumber} es un numero`);