//Sitio web oficial: https://www.javascript.com

/////////////////////////////////////
//Comentario en una linea

/////////////////////////////////
/*Comentario en 
multiples
lineas */

///////////////////////////////////
//constante
const languajeName = "JavaScript";

//variables
let num = 88;
let text = 'hola, que tal!!';
let bool = false;
let nullValue = null;
let undefinedType = undefined;

///////////////////////////////////////////
console.log(`¡Hola, ${languajeName}!`);
