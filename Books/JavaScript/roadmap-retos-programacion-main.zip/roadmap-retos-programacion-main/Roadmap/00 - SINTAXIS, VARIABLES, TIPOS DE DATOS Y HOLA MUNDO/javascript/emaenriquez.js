//SITIO OFICIAL JAVASCRIPT
// https://ecma-international.org/

//TIPOS DE COMENTARIOS
// Comentario de una línea

/* Comentario
de varias
lineas*/

// VARIABLE Y CONSTANTE
let numero = 2;
const lenguaje = "Javascript";

// TIPOS DE DATOS PRIMITIVOS
// Number
let fecha = 2003;

//String
let name = "Emanuel";

//Boolean
let verdadero = true;
let falso = false;

//Null
let pais = null;

//Undefined
let age;

console.log(`Hola ${lenguaje}`)