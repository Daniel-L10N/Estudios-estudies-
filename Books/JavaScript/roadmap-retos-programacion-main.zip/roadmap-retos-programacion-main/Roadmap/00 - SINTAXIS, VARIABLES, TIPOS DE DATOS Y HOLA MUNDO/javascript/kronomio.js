// #00 SINTAXIS, VARIABLES, TIPOS DE DATOS Y HOLA MUNDO
//https://www.javascript.com/

// One line

/*

    Multiple Lines

*/

let variable=0;

const constant="Hello World!"

let string="hello";
let number=54;
let bigint=58469854587859652;
let boolean=false;
let decimal=6.54;
let symbol= symbol("newSymbol");
let nullValue=null;
var  undefinedValue=undefined;

console.log("¡Hola Javascript!");
