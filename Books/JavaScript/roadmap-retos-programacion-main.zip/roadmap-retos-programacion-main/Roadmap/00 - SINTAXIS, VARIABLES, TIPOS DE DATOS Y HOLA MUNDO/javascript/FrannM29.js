// Sitio oficial del lenguaje en cuestion https://developer.mozilla.org/es/docs/Web/JavaScript

/*
esto
es
un
comentario
de
varias
lineas
*/
var lenguajeName = "JavaScript";
var numberType = 77;
var booleanType = "false";
var stringType = "string";
var nullType = null ;
var undefinedTipe = "undefined1";
var bigInt = 1000000000000000000000000000;

console.log ("Hola, JavaScript");