// https://retosdeprogramacion.com/

/*
https://retosdeprogramacion.com/
https://retosdeprogramacion.com/
https://retosdeprogramacion.com/
*/

let nombre = lucas
const apellido = bernaola
let edad = 34
const añoNacimiento = 1989
let casado = true

let string = JavaScript
let number = 123456
let isBooleanTrue = true
let isBooleanFalse = false
let isNull = null
let indefined;
let myArray = ["Hola", "como", "estas", "?"]
let myObject = {nombre: "lucas", apellido: "bernaola"}

console.log("Hola JavaScript");
