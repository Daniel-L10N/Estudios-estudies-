// No hay sitio web oficial, lo mas cercano es https://developer.mozilla.org/es/docs/Web/JavaScript

// Comentario de una linea 

/*Comentario de 
varias 
lineas */
//declaracion de variable y constante
var variableQueNoSeUsa = 1;
let variable = 2;
const constante= 3;

//variables de datos primitivos

let numero = 123;
let string = 'JavaScript'
let boolean = true;
let nulo = null;

console.log('Hola, '+ string);
