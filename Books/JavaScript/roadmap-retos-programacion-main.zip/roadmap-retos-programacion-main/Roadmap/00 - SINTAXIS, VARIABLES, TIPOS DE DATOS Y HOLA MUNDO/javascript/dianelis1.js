// https://developer.mozilla.org/es/docs/Learn/JavaScript/First_steps/What_is_JavaScript
// This is a one line comment
/* But this is a 
      multi-line 
        comment. */

var myVariable = 3;
const MY_CONST = 4;

var string = "Hello";
var boolean = true;
var numbers = 2;

console.log( "¡Hola, Javascript !" );
