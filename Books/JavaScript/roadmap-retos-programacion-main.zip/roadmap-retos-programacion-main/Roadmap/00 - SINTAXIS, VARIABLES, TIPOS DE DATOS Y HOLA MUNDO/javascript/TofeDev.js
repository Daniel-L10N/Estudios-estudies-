// No hay sitio oficial, pero existe estos famosos documentos sobre js: https://developer.mozilla.org/es/docs/Web/JavaScript

// Comentario de una linea

/* Comentario de
*varias lineas 
*/

var x = 50 //Variable global
let y = 20 //Variable local
const z = 100 //Variable local, que NO se puede cambiar su value

let String = "JavaScript"
let boolean = true
let number = 40
let float = 1.52
let dnull = null
let bigInt = 152n
let indefinido = undefined
let array = [1, 2, 3, 4, 5]
let objeto = {lenguaje: "JavaScript", reto: 0}
let simbol = Symbol('algo')

console.log("¡Hola, " + String + "!")