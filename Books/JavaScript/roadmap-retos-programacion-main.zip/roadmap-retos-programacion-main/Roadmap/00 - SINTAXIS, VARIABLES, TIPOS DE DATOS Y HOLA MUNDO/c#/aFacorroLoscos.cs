// Pagina Web de documentacion de C#: https://learn.microsoft.com/en-us/dotnet/csharp/
//Librerias necesarias
using System;
//---------
class Reto00
{
    static void Main()
    {
        //Comentario de codigo en 1 linea

        /* Comentario
         * de
         * codigo
         * varias lineas
         */

        // Declaracion de variable y constante
        int variable = 1;
        const int variableConstante = 1;

        // Tipos de datos Primitivos
        // Booleanos
        bool booleanData = true;
        // Byte,Short,Int y Long
        byte valorByte = 99;
        short valorShort = 100;
        int entero = 33;
        long valorLong = 10239L;
        // Float, Double y Decimal
        float numeroFlotante = 33.33F;
        double numeroDoblePrecision = -0.213;
        decimal decimales = 42.013M;
        // Char
        char caracter = 'b';

        // Hello, world
        Console.Write("�Hola, C#!");
        
    }
}