// https://dotnet.microsoft.com/es-es/languages/csharp

/*
    Comments
*/

// single-line comment

/*
    this is a
    multi-line comment
*/

/*
    Vars And Constants
*/

string name = "kodenook";
const int age = 20;

/*
    Primitive Types
*/

string country = "chile";
char letter = 'c';
int ageCountry = 200;
long peopleQ = 20000000;
float myFloat = 3.5F;
double myDouble = 5.323D;
bool myBool = true;


Console.WriteLine("¡Hello, C#!");
