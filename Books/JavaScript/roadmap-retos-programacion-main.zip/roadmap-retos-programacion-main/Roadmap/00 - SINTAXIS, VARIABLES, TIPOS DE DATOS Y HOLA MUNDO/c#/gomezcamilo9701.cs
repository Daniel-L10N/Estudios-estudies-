using System;

namespace CeroCero
{
    class CeroCero
    {
        static void Main(string[] args)
        {
            //https://dotnet.microsoft.com/es-es/languages/csharp
            //Comentario
            /* O Comentario*/
            var variable = "la variable ve";
            const string CONSTANTE = "Constantebrrr";
            double doublee = 2.3;
            int inttt = 2;
            float floattt = 1.2f;
            decimal decimalll = 12.2m;
            bool bolll = true;
            int[] intArray = {1,2,3,4};
            (int, string) tuplaa = (2, "tupla");
            Console.WriteLine("¡Hola, C#!");
        }
    }
}