using System;

namespace Ishimaku
{
    class Program
    {
        static void Main(string[] args)
        {
            //https://learn.microsoft.com/es-es/dotnet/csharp/tour-of-csharp/
            //un comentario xd

            /*
            comentario
            en
            bloque
            */

            //se declara una variable
            int variable;

            //se declara una constante
            const int constante;

            //tipos de variables fundamentales
            int variableint = 1;
            float variablefloat = 0.25f;
            string variablestring = "variablestring";
            bool variablebooleano = true;

            //mensaje en consola
            System.Console.WriteLine("�Hola, C#!");
        }
    }
}


