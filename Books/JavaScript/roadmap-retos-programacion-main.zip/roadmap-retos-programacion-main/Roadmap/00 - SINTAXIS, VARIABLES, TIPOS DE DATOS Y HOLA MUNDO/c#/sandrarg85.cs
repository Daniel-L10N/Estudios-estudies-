// Ejercicio 1: Sitio oficial https://dotnet.microsoft.com/es-es/languages/csharp

// Ejercicio 2: // Comentario en una linea 

/* Comentario
 * en varias
 * lineas */

using System;
using System.Linq.Expressions;

namespace SandraDev
{
    class Program
    {
        static void Main(string[] args)
        {
            // Ejercicio 3 - Variable y Constante declarada

            int Variable = 0;
            const string MiConstante = " ";

            // Ejercicio 4 - Datos primitivos

            int NumeroEntero = 1;
            long NumeroEnteroLargo = 1234567890;
            float NumeroDecimal = 1.5f;
            double NumeroDecimalLargo = 12.50;
            decimal NumeroDecimalExtraLargo = 123567.50m;
            string Texto = "hola";
            char Letra = 'A';
            bool verdadero = true;

            // Ejercicio 5 - Imprimir por pantalla

            Console.WriteLine("¡Hola, c#!");



        }
    }
}
