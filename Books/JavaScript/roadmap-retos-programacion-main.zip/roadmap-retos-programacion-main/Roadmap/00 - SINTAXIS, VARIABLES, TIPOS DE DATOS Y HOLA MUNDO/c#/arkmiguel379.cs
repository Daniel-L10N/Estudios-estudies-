﻿//https://learn.microsoft.com/es-es/dotnet/csharp/

//Este es un comentario de una sola linea en C#

/* Este es un comentario
   de varias lineas en C#*/

string lenguaje = "CSharp";
const double myConstante = 3.14;

int entero = 379;
string cadena = "Esto es un a cadena de texto";
char caracter = 'M';
bool booleanD = true;
float flotante = 13.5f;
double doble = 33.79;
long numLargo = 379257172839465L;
decimal numDecimal = 15.9M;

Console.WriteLine($"Hola {lenguaje}");
