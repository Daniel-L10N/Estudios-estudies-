//comentario de una sola linea 

/*cometario de 2
o mas lineas
*/
/* https://dotnet.microsoft.com/es-es/languages/csharp
https://learn.microsoft.com/en-us/dotnet/csharp/
*/
class daeduol{
//variables y constantes
dynamic myDynamic = 6;
const string MyConst = "mi constante";
string myString = "Esto es una cadena de texto";
var myVar = "variable de tipo inferido";
//tipos de datos primitivos
byte number8 = 1;
short number16 = -32768;
int myInt = 7;
long number64 = 2147483647;
float myFloat = 6.5f;
double myDouble = 3.0;
char char16 = 'a';
bool myBoolean = true;
public static void Main(string[] args)
{
System.Console.WriteLine("¡Hola, C#!");
}
}