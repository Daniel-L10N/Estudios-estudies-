// https://cplusplus.com/
#include<iostream>
using namespace std;
// Comentario de una línea
/*Comentario de 
varias líneas*/
int main(){
	// VARIABLE Y CONSTANTE
	double variable = 2.35;
	const double PI = 3.14159;

	// TIPOS DE DATOS PRIMITIVOS
	// Cadenas de texto
	string mi_nombre = "Bard";
	string mi_frase = "Hola, soy Bard";

	// Enteros
	int mi_edad = 18;
	float mi_altura = 1.75;

	// Flotantes
	double mi_peso = 75.5;
	double mi_sueldo = 1500.00;

	// Booleanos
	bool soy_mayor_de_edad = true;
	bool soy_soltero = false;

	// Impresión
	cout << "¡Hola, C++!" << endl;
}
