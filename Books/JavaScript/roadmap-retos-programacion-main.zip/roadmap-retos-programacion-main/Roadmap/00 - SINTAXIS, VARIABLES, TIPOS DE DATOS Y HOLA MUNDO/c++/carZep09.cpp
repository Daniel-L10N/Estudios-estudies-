#include <iostream> 
using namespace std; 

int main()
{
    // https://isocpp.org/

    // comentario de una sola linea 
    
    /* También esto 
        es un comentario 
        en varias lineas */


    string mi_variable = "Esta es mi variable"; 
    mi_variable = "Un nuevo mensaje en mi variable"; 

    const string MI_CONSTANTE = "Constante, ¡esta fija!"; 

    int entero = 20;
    double doble = 5.3; 
    float flotante = 10.2f; 
    bool booleo = true; 
    string cadena = "Mi texto";
    char caracter = 'E';  

    cout << "Hola, C++" << '\n';  


    return 0; 
}
