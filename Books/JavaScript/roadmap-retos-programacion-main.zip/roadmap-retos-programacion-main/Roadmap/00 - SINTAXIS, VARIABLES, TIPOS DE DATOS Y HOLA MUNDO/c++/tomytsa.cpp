// https://isocpp.org/

// Comentario de una linea

/* Comentario de 
varias lineas*/

#include <iostream>
using namespace std;

int main(int argc, char const *argv[])
{
    


    int variable;
    const int numero = 1;



    
    char caracter; 
    int entero = 1;
    short enteroCorto; 
    long enteroLargo;
    bool booleano;
    float flotante;  

    cout << "¡Hola, C++!" << endl;


    return 0;
}
