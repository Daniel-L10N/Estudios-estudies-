// @RoniPG

#include <iostream>

using namespace std;

int main(){
	//URL = https://cplusplus.com/
	// Comentario en una linea.
	/*
	 * Comentario de varias lineas.
	*/
	short sh = 0 ; // start= -32768; end = 32767 ;
	int in = 0; // start= -2^31; end = 2^31 ;
	long long lo = 0; // start= -2^63; end = 2^63 ;
	float fl = 0.0; // ---> numeros decimales simples con 7 decimales.
	double dl = 0.0; // ---> numeros decimales largos con 15 decimales.
	bool bo = false; // ---> valores: true, false(por defecto).
	char ch = 'a'; //---> valor para una letra/caracter.

	//Para crear una constante se añade 'const' antes de indicar el tipo de variable.
	//Destacar el 'unsiged' antes de la variable para utlizar solo los valores positivos.
	const int fi=0;

	cout<<"hola C++";
	return 0;
}
