//Sitio oficial -> https://isocpp.org/

//Comentario de una sola línea

/*Comentario
de
múltiples
líneas*/

#include <iostream>

int main()
{
    const int year = 2024;
    int number = 12;
    float distance = 24.7;
    bool check = false;
    char *letter = "M";

    printf("Hola, C++ !");

    return 0;
}