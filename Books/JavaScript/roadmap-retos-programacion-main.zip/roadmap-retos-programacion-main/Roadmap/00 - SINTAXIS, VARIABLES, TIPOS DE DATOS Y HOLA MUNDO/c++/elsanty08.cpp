// https://isocpp.org/ 
//ademas usaré la documentacion de 
//https://dev.epicgames.com/documentation/en-us/unreal-engine/epic-cplusplus-coding-standard-for-unreal-engine

// este es un comentario en una sola linea

/*
esto es un comentario
en varias lineas
*/

#include <iostream>
#include <string>

int main() {
//variable
int num = 08;

//datos primitivos

int numerico = 08;
float decimal = 2.3f;
double decimal2 = 3.5;
bool boleana = true;

std::string Hola = "Este es el string";

const float PI = 3.1416;

std::cout << "!Hola C++¡";

return 0;

}
