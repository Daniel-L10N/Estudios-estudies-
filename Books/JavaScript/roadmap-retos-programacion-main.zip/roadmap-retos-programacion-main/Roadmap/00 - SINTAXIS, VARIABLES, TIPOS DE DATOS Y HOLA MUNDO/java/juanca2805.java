public class juanca2805 {
 
    // Lenguaje elegido: Java https://www.java.com/es/
   /* Tipos de comentario
     que existen :)
    */
   /*
    * Otro tipo de comentario
    * 
    */
   //Crear una variable y una constante si el lenguaje lo soporta
public static void main(String[] args) throws Exception { 

   int  Number = 3;
   String Cadena = "hola";
   boolean flag = false;


   // Constante
   final String constante = "Java!";

   //Salida por consola 

   System.out.println(Cadena + " " + constante);
}
}