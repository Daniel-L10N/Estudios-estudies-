public class AleFine {
    /* Crea un comentario en el código y coloca la URL del sitio web oficial del
    lenguaje de programación que has seleccionado. */

    
    //Página Oficial: https://www.java.com/es/


    /*Representa las diferentes sintaxis que existen de crear comentarios
        en el lenguaje (en una línea, varias...). */

    // Comentario Tipo 1:
    // Comentario Tipo 1.

    /*Comentario Tipo 2:
     * 
     * 
     * 
     * Comentario Tipo 2.
    */
    
    
    //Crea una variable (y una constante si el lenguaje lo soporta).
    int var;
    final double pi = 3.14159;


    //Crea variables representando todos los tipos de datos primitivos
    int var_2;
    boolean var_8;
    char var_9;
    double var_5;
    float var_3;
    byte var_10;
    short var_11;
    long var_12;

    public static void main(String[] args) {
    System.out.println("¡Hola, "+"Java!");
    }
}
