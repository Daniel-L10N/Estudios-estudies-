/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication16;

/**
 *
 * @author DAVID
 */
public class JavaApplication16 {

 
    public static void main(String[] args) {
        
        /*__________ 1 _______________
         Link del sitio oficial del Lenguaje: 
        https://www.java.com/es/
        */
        
        //__________ 2 _______________
        //EJEMPLO COEMTARIO DE (1) LINEA
        
        
        /* _________ 3 _______________
        
        EJEMPLO COMENTARIOS EN BLOQUE
        
        */
        
        /* _________ 4 _______________
        
                 Variable
        
       */
        
        int VARIABLE_A = 15;

        final int CONSTANTE_EJE = 7 ;
        
        /* _________ 4 _______________
        
             Tipos de Datos Primitivos
        
       */
        
        
        long EJEMPLO_1 = 777666;
        
        char EJEMPLO_2 = 'L';
        
        String EJEMPLO_3 = "Manolo";
        
        System.out.println("My name is "  + "Manolo" );
        
        boolean  EJEMPLO_4 = false;
        
        
        
         System.out.println("¡Hola, Jsva");
    }
    
}
