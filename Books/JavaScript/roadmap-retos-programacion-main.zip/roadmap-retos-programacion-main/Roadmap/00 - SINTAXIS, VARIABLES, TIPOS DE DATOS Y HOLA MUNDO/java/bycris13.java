/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Cris
 */
public class bycris13 {
    //Declaracionde una constante
    static final int MI_CONSTANTE = 10;

    public static void main(String[] args) {
        // https://www.java.com/es/

        // comentario de una linea.
        /* comentario de vaias lineas
        puede contener multiples lieneas de codiogo.
         */
        int miVariable = 10;

        
        // Enteros
        int entero = 10;
        byte byteEntero = 127;
        short shortEntero = 32000;
        long  longEntero = 1234567890L;
        
        // Decimales
        float decimalFlotante = 3.14f;
        double  decimalDoble = 3.14159265359;
        
        // Caracteres
        char caracter  = 'A';
        
        // Booleano
        boolean booleano = true; 
        
        String nombreDelLenguaje = "java";
        System.out.println("¡Hola, "+nombreDelLenguaje+"!");
    }

}
