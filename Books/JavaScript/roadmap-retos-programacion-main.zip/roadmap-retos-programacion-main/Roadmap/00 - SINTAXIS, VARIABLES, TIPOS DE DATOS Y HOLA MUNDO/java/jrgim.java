public class Jorge {
    // Lenguaje elegido: Java https://www.java.com/es/
    /*
     * Tipos de comentarios //
     */
    public static void main(String[] args) throws Exception {
        int a = 0;
        long b = 0L;
        float c = 9.4f;
        double d = 3.5;
        char e = 'a';
        String f = "Hola";
        boolean g = true;
        System.out.println("!Hola, Java!");
    }
}
