public class FrankMon03 {
  
    public static void main(String[] args) {
      //https://www.java.com/es/
      
      /* Sintaxis 1 de comentado */
      // Sintaxis 2
      
      final int numc = 5;
      int num1 = 900000;
      long num2 = 9000000;
      short num3 = 9999;
      double dec1 = 8.9911111;
      float dec2 = 1.2f;
      char carac1 = 'F'; 
      String lang = "Java";
      String texto;
      boolean opt;
      opt = false;
      System.out.println("Hola, "+ lang);
    }//main
  }//class 
  