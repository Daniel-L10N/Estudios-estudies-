public class AmadorQuispe {
    // Esto es un comentaria de una sola linea
    // URL Oficial: https://dev.java/
    /*
     * Esto esComentario
     * de varias lineas.
     */
    static final String constante = "Soy Dev";

    public static void main(String[] args) {

        // Enteros
        byte diasMes = 31;
        short diasLustro = (12 * 31) * 5;
        int velocidadLuz = 299792458;
        long anioLuz = velocidadLuz * 365;
        // Flotantes/Decimales
        float pi = 3.1415926535f;
        double e = 2.718281828459045235360;
        // Caracteres
        char letraA = 'a';
        char letraANumerico = 61;
        // Boleanos
        boolean verdadero = true;
        boolean falso = false;

        // Tipo de datos Wrapper
        // ejemplo
        String saludo = "Hola mundo";

        System.out.println("¡Hola, JAVA!");
    }
}
