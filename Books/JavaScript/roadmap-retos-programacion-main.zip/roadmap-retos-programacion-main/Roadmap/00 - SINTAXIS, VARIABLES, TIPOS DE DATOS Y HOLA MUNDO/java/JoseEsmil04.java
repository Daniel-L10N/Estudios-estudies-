public class JoseEsmil04 {
    public static void main(String[] args) {
        // Sitio Oficial del Lenguaje
        // https://www.java.com

        // Este es un comentario de una linea.

        /*
         * Este es un Comentario
         * De Varias lineas!
         */

        // Variable
        String variable = "¡Hola,";

        // Constante
        final String constante = "Java!";

        // Tipos primitivos
        String myCadena = "String by Esmil";
        char myChar = 'E';
        int myNumero = 44;
        byte myByte = 4;
        double myDouble = 105.44;
        float myFloat = 33492.221f;
        long myLong = 987654321;
        boolean myBoolean = true;

        // Salida por consola
        System.out.println(variable + " " + constante);

    }
}