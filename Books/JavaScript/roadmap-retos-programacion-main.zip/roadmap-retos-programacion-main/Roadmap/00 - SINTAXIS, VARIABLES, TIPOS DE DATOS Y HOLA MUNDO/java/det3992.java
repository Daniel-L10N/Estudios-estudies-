package retosDeProgramacion;

public class Ejercicio01 {
	public static void main(String[] args) {

		// https://www.java.com/es/

		// COMENTARIO DE UNA UNICA LINEA

		/*
		 * COMENTARIO DE VARIAS LINEAS
		 * 
		 */

		int myNum = 0; // he definido una variable de tipo int con valor 0
		final double pi = 3.14; // para definir una constante basta con poner el modificador "final" delante del
								// tipo de dato

		String myName = "David"; 		// Cadena de texto con mi nnombre.
		char type = 'a';				// Variable de un solo caracter.
		boolean myBool = true; 			// Variable de tipo booleano.
		int myNum2 = 39; 				// Variable de tipo entero.
		double alonsoVictory = 33.33; 	//Variable de tipo decimal.
		
		System.out.println("¡Hola, Java!");
	}
}
