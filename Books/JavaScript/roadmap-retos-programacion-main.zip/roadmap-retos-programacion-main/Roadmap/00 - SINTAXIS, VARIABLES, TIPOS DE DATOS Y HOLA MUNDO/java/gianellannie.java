public class Main {
  public static void main(String[] args) {
    // URL del sitio web oficial de Java: https://docs.oracle.com/en/java/
    
    // Comentario en una línea de código
    /* 
    Comentario 
    en varias 
    líneas de código
    */
    
    var variable = 1;
    final int constante = 5;
    
    // Tipos de datos primitivos
    byte numeroByte = 1;
    short numeroShort = 10;
    int entero = 15;
    long numeroLong = 100;
    double doble = 15.64;
    float flotante = 15.64f;
    char caracter = 'C';
    boolean booleano = true;
    
    System.out.println("¡Hola, Java!");
  }
}