//https://www.java.com/es//

//Ejemplo de un comentario en una linea//

/*Ejemplo 
de comenatrios 
en varias 
lineas
*/
public class BladimirVelasco {
    static final String constante = "Hola esto es una constante";



public static void main(String[] args) {


// Tipos de datos primitivos
int numeroEntero = 10;
double numeroDecimal = 3.14;
boolean esVerdadero = true;
char caracter = 'A';
float numeroFlotante = 3.1415926535f;
long numeroLargo = 299792458;
byte numeroByte = 127;
short numeroCorto = 32767;

// Tipos de datos de referencia
String cadenaTexto = "Hola, mundo!";

// Imprimir en consola

System.out.println("¡Hola, JAVA!");
}
}