public class AlgelOro {

    //Esta es la documentación oficial de Java https://dev.java/
 
    /**
     * Este es un comentario multilinea
     * Nos sirve para comentarios extensos 
     */ 
 
     //Variable constante
     public static final String CONSTANTE = "Esta es una constante";

     public static void main(String[] args) {
         
     /**
      * Tipos de datos en Java
      */
 
      
     //Variable tipo texto
        String varString = "Variable tipo string";
        //Variable tipo entero
        int varInt = 12;
        //Varibale tipo Long
        long varLong = 4L;
        //Variable tipo boolean
        boolean isBoolean = false;
        //Variable tipo float
        float varFloat = 9.7f
        //Variable tipo double
        double varDouble = 6.4d
        //Variable tipo char
        char varChar = \u0000;
        //Variable tipo byte
        byte varByte = 0;
        
        System.out.println("¡Hola, Java!")
    }
 
 }