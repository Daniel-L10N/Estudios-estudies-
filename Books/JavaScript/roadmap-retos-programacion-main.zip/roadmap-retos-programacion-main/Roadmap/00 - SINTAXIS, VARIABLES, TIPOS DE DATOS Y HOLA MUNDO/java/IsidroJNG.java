public class IsidroJNG {
    public static void main(String[] args) {
		// Para cometarios en una línea
		
		/* Para comentarios de
		 * varias líneas.
		 */
		
		/**
		 * Para textos largos
		 * como documentación.
		 */
		
		// Tipos de datos primitivos enteros
        byte miByte = 10; // 8 bits
        short miShort = 5000; // 16 bits
        int miInt = 1000000000; // 32 bits
        long miLong = 500000000000000L; // 64 bits
        long otroLong = 6_000_000_000_000_000l; //64 bits
        
        // Números decimales
 		float decimalCorto = 234.009f;
 		double notacionCientifica = 3.345623E-10;
 		
 		// Booleanas
		boolean condicion = true; // 1 bit
		
		// Carácter
		char caracter = 'c'; // 16 bits
		
		// Constante
		final float PI = 3.141592f;
		
		System.out.println("Hola, Java!");
		
	}
}
