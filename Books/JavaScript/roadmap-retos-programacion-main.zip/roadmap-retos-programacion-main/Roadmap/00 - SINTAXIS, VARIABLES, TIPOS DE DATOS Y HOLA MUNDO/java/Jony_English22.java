public class Jony_English22 {

    public static void main(String[] args) {

        //https://docs.oracle.com/en/java

        //Este es un comentario de una linea

        /*
        Este es un comentario
        de varia lineas
         */

        //Constante
        final String my_constant = "#00- SINTAXIS, VARIABLES, TIPOS DE DATOS Y HOLA  MUNDO";

        String my_variable = "Variable de tipo string"; //Variable

        //Tipos de datos
        byte my_byte = 127;
        short my_short = 32727;
        int my_int = 22;
        long my_long = 1000000000;
        float my_float = 12.12f;
        double my_double = 56.978;
        String my_String = "Esta es una cadena de texto";
        char my_char = 'a';
        boolean my_boolean = true;
        boolean my_boolean2 = false;

        System.out.println("¡Hola Java!");
        System.out.println("Este fue el ejercicio: " + my_constant);
    }

}
