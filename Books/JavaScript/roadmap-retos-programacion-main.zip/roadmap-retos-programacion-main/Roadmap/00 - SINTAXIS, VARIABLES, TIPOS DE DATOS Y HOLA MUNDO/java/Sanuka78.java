public class Sanuka78 {
    
    public static void main(String[] args) {

// https://www.java.com/es

// Comentario de una línea
/* Esto es un comentario
  en varias líneas */

//Crear una variable
int edad = 8;

//Crear una constante
final String nombre = 'miNombre';

//Crear datos primitivos
char letra = 'S';
String cadena = 'hola';
byte num = 1;
short num2 = 2;
int num3 = 3;
long cantidad = 23;
Double numero = 3.0;
float altura = 50.0;
boolean booleano = false;

//Imprimir por pantalla
System.out.println ("Hola Mundo");
    }
}
