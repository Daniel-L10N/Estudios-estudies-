package javaExample_;

public class Sintaxis_Variables_Tipos_00 {
	public static void main(String args[]) {
		//https://dev.java/learn/
		
		/*Comentario_de_varias_lineas
		  Se_puede_comentarun_parrafo*/
		
		//VARIABLES
		//Dato_tipo_cadena
		String cadena = "Esto es una cadena";
		
		//Dato_tipo_entero
		int entero = 18;
		
		//Dato_tipo_flotante
		float flotante = 23.5f;
		
		//Dato_tipo_double
		double decimal = 25.5;
		
		//Dato_tipo_caracter
		char caracter = 'D';
		
		//Dato_tipo_booleano
		boolean booleano = true;
		
		//CONSTANTES
		final String constante = "Valor de constante";
		
		//IMPRESION_DE_DATOS_POR_CONSOLA
		System.out.println(cadena);
		System.out.println(entero);
		System.out.println(flotante);
		System.out.println(decimal);
		System.out.println(caracter);
		System.out.println(booleano);
		System.out.println(constante);
		
		//
		String lenguaje = "Java";
		System.out.println("Hola " + lenguaje +"!!");

	}
}
