//Sitio oficial de java: https://www.oracle.com/es/ 

/**
 * pguillo
 */

 public class pguillo {
    //Se puede generar una constante a través de la palabra reservada final
    public static final String CONSTANTE = "CONSTANTE";

    public static void main(String[] args) {
        // variables
        boolean booleana = true;
        float flotante = 6.9f;
        int integer = 2;
        char character = 'H';
        byte bte = 0;
        short shor = 1;
        long lon = 33L;
        double doble = 1.23d;
        
        System.out.println("Hola, Java");
    }
}