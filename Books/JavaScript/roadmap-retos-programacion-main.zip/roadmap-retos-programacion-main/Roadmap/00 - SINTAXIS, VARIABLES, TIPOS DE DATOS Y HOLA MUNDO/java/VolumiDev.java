/*EJERCICIO:
 * - Crea un comentario en el código y coloca la URL del sitio web oficial del
 *   lenguaje de programación que has seleccionado.
 * - Representa las diferentes sintaxis que existen de crear comentarios
 *   en el lenguaje (en una línea, varias...).
 * - Crea una variable (y una constante si el lenguaje lo soporta).
 * - Crea variables representando todos los tipos de datos primitivos
 *   del lenguaje (cadenas de texto, enteros, booleanos...).
 * - Imprime por terminal el texto: "¡Hola, [y el nombre de tu lenguaje]!"*/
public class VolumiDev {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// URL DE JAVA: https://www.java.com/es/
		
		//ESTO ES UN COMETARIO EN UNA LINEA
		
		/*ESTO ES UN COMETARIO EN PARRAFO
		 * COMO SE HIZO ARRIBA CON EL E
		 */
		
		//CREAMOS UNA VARIABLE DE TIPO CADENA
		String saludo="Hola, Java";
		//CREAMOS UNA CONSTANTE POR EJEMPLO CON EL NUMERO PI;
		final double pi=3.1416;
		//VARIABLE ENTERA BYTE
		byte n1=1;
		//VARIABLE ENTERA SHORT
		short n2=2;
		//VARIABLE ENTEREA INT
		int n3=3;
		//VARIABLE ENTERA LONG
		long n4=4;
		//VARIBALE REAL FLOAT
		float n5=5;
		//VARIABLE REAL DOUBLE
		double n6=6.2;
		//VARIABLE CARACTER
		char caracter='a';
		//VARIABLE BOOLEAN
		boolean condicion=true;
		//VARIALBE CADENA DE TEXTO
		String cadena="Esto es una cadena de texto";
		
		System.out.println(saludo);

	}

}
