public class Daeduol {
    //    linea comentada
    /*multiples lineas comentadas
    daeduol
    java
    */
//    https://dev.java/

    /* Variables primitivas */
    byte number8 = 1;
    short number16 = -32768;
    int number32 = 12;
    long number64 = 2147483647;
    float aFloat32 = 1.13f;
    double height = 1.70;
    boolean SkyIsBlue = true;
    char char16 = 'a';
    /*Variables de tipo string*/
    String nombre = "Juan";
    String apellido = "Pérez";

    public static void main(String[] args) {
        System.out.println("¡Hola Java!");
    }
}
