public class  jcrodmir{

/*
 Programm Language/ Programmiersprache: Java
 Official Java Website / offizielle Java WebSite: https://docs.oracle.com/javase/8/docs/
 Other Java Website/ andere Java WebSite : https://www.javatpoint.com/java-tutorial

*/

//  Diferents types of comment one line/verschiedene Typen von Kommentaren

/*  multiples lines/ mehrere Zeilen
*/

    /**
     *  Documentation
     *
     * */

//Create a variable and constant/Variable und Konstante erstellen
/*
    The variables at Java have the type of the variable the name and the value, if you want a constant, must add
    a the keyword final.
    Die Variablen bei Java haben den Typ der Variablen, den Namen und den Wert, wenn Sie eine Konstante wollen, müssen Sie
    ein das Schlüsselwort final.

 */

    int variableNumber = 8;
    final int finalNumber= 9;

    //Primitives Types/ primitive Datentypen
/*
    Byte/Short/Int/Long/Float/Double/Boolean/Char
 */
    byte ReallySmallNumber=10;
    short smallNumber=10000;
    int number= 100000;
    long  ReallyBigNumber=53856421646L;
    float decimalNumber= 2.5f;
    double decimalBigNumber= 52556.684684446;
    boolean trueOrFalse= true;
    char character= 'A';

    public static void main(String[] args) {
        System.out.print("Hello World");
        System.out.print("Hallo Welt");
    }
}