public class vikinghost {

    public static void main(String[] args) {
        
        //Este es el enlace a la web de java = https://www.java.com/es/

        //comentario de una linea
        
        /*comentario
                de bloque*/
        
         /**
          *  Comentario de documentación.
          */
        
        //Crea una variable y una constante.

        short variableInicial;
        

        final int value = 234; 

        //Recogidos los tipos primitivos
        String texto = "cadena de texto";
        byte num0 = -128;
        short num1= 3;
        int num2= 2;
        long num3 = 92211703;        
        float num4 = 2.1233f;
        double num5 = 3.222232;
        char caract = 'a';
        boolean value2 = true;

        //Imprime por terminal el texto: "¡Hola, [y el nombre de tu lenguaje]!"

        System.out.println("Hola, Java!");
    }
        
    
}    
   

       








    










 