public class chalaito88 {
    public static void main(String[] args) {
        //https://www.java.com/es/

        //Esto es un comentario de una sola línea.
        /*Esto
        * es
        * un
        * comentario
        * de
        * más
        * de
        * una
        * línea*/

        //Constante
        final float PRECIO = 10.25f;
        //Variables
        float preciofinal = 50.30f;
        double precioManzana = 1.50;
        short cosita = 10;
        int numero = 80;
        long numeroUtilizado = 100000000;
        String nombre = "Daniel";
        char vocal = 'A';
        boolean siono = true;
        byte codita2 = 6;

        System.out.println("Hola Java!!");
    }
}
