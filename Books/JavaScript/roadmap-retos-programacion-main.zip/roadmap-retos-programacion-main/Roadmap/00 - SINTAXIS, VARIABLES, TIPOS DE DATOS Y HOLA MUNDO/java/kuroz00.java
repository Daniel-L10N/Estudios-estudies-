public class kuroz00 {
    public static void Main(String[] args){
        //hola, https://www.oracle.com/java/
        /*
         comentario de varias lineas
         */
        // .-.- Datos primitivos.-
        Integer entero = 10;
        float flotante = 10;
        double Fdoble = 10.00; 
        char caracter = 'A';
        String myString = "Java";
        boolean booleano = true;
        //Constante
        final String constante = "Hola, soy una constante! :D";
        System.out.println("Hola " + myString + "!!!");
    }
}