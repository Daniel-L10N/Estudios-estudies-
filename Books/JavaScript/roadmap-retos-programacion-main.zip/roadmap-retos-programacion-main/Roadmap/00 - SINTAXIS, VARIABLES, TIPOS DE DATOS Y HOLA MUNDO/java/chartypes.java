// https://java.com

// Comentario de una sola linea

/*
  Comentario de multiples lineas
*/
public class chartypes{
  public static void main(String[] args){

    char var = 'a';
    final CONSTANT = 10;
    int interger = 3;
    float floating = 3.14f;
    double double = 3.14;
    boolean bool = true;
    String lenguageName = "Java";

    System.out.println("Hola," +lenguageName+"!");

  }
}
