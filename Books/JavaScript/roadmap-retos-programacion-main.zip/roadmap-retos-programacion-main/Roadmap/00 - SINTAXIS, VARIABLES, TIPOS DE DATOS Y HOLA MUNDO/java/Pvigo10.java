// Página Oficial de Java : "https://www.java.com/es/"

// Comentario de una línea
/*
* Comentarios
* de varias
* líneas
*
* */

public class pvigo{
  public static void main(String[] args) {
    //Una variable
    String name_day;
    //Una constante
    final int year = 2024;

    // Variable de todos los datos primitivos
    //char
    char letra = 'a';
    // byte
    byte edad = 31;
    // short
    short temperatura = -10;
    // int
    int numero_Estudiantes = 120;
    // long
    long numero_Poblacion = 1000000000;
    // float
    float precio = 14.50f;
    // double
    double area = 3.1415926535;
    // boolean
    boolean es_humano = true;

    // Imprimir por terminal :
    System.out.println("¡Hola, JAVA!");

  }
}
