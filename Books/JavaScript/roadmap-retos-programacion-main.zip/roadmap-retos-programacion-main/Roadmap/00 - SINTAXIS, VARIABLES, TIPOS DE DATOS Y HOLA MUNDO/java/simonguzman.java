
public class simonguzman {
    //https://dev.java/

    //Comentario en una linea

    /**
     * 
     * Comentario en varias lineas(Documentacion)
     */

    /*
    Documentacion en varias lineas
     */ 
    public static void main(String[] args) {
        
        //Datos primitivos y creacion de variables
        //Variables con valores numericos
        byte Byte = 127;
        short corto = 1;
        int entero = 2;
        long numerogrande = 3;
        float numeroFlotante = 3.3f;
        double numeroDoble = 3.3;

        //Representaciones de valores numericos

        //Numero decimal
        int decimalValue = 16;
        //Numero hexadecimal
        int hexadecimalValue = 0x1a;
        //Numero binario
        int binaryValue = 0b11010;

        //Expresiones para punto flotante
        double double1 = 123.4;

        //Notaciones diferentes
        double double2 = 1.234e2;
        float f1 = 123.4f; 

        //Variables de texto(Lineas de caracteres y cadenas de texto)
        String cadena = "Texto";
        char Caracter = 'a';
        boolean result = true;

        System.out.println("¡Hola, java!");
    }

}
