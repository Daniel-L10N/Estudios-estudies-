//Sitio oficial de Java: https://www.java.com/es/

//Comentario simple

/*Comentario de 
* varias
* líneas
*/

public static void main(String[] args) {

    // Variable y constante
    String a = "Esto es una variable";
    
    final double b = 3.1416;
    
    // Tipos de datos
    byte c = 1;
    int d = 2;
    double e = 3.3;
    long f = 4;
    float g = 5;
    short h = 6;
    char i = 7;
    boolean j = true;
    String k = "Hola";
    
    System.out.println(k +" Java");
    }
    