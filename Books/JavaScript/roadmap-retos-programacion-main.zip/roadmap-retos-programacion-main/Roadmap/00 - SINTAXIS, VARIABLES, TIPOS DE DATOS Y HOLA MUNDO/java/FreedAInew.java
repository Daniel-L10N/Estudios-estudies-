public class FreedAInew {
    public static void main(String[] args) {
        System.out.println("Hello world!");
//create a comment in the code and place the URL of the official website of the programming language you have selected.

        /*These comments are used to add longer explanations or to comment out blocks of code that should not be executed. */

/**
 *Within them, a specific syntax is used to describe elements such as classes, methods, variables.
 *The comments are processed by the javadoc tool to generate HTML documentation of the code.
 */

//Create a variable (and a constant if the language supports it).

        int age = 7; // Integer variable with initial value 7
        final int PI=314159; // Approximate value of Pi




//Creates variables representing all the language's primitive data types (text strings, integers, booleans...).

                byte weight = 30;
                short temperature = 46;
                int ageInYears = 7;
                long nationalId = 1234567456L;
                float pi = 3.141592f;
                double e = 2.718281828459045;
                boolean isStudent = true;
                char symbol = '$';

                System.out.println("hi java "+symbol);
            }
        }
