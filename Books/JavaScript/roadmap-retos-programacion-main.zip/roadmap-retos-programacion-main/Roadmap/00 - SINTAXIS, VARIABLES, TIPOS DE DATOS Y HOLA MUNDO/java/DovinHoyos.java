public class DovinHoyos {

    public static void main(String[] args){

        // https://www.java.com/es

        //Esto es un comentario en linea

        /*
        este es un comentario
        en varias lineas 
        */

        var miVariable = "Hola";
        final String MI_CONSTANTE = "Java!";
        
        //tipos de datos primitivos
        byte numByte = 127;
        short numShort = 32767;
        int numInt = 2147483647;
        long numLong = 9223372036854775807L;

        double numDouble = 1.7976931348623157E308;
        float numFloat = 3.4028235E38F;

        char caracter = '@';

        boolean bool = true;

        System.out.println(miVariable+", "+MI_CONSTANTE);




        


    }
}