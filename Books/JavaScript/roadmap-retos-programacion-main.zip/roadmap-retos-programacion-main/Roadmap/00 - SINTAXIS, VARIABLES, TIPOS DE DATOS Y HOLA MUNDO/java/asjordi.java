public class Main {

    /**
     * https://www.oracle.com/java/technologies/downloads/
     * https://www.java.com/es/
     * https://devdocs.io/openjdk~19/
     */

    /**
     * Comentario de varias líneas
     * @param args
     */
    public static void main(String[] args) {
        // Comentario de una linea

        // Variable
        String reto = "Ejercicio 1";

        // Constante
        final String leng = "Java";

        // Tipos de datos

        String cadena = "Hola";
        int num1 = 1;
        float num2 = 1.0f;
        double num3 = 1.0;
        long num4 = 1L;
        short num5 = 1;
        byte num6 = 1;
        boolean bool = true;
        char letra = 'a';

        System.out.println("¡Hola, Java!");

    }

}
