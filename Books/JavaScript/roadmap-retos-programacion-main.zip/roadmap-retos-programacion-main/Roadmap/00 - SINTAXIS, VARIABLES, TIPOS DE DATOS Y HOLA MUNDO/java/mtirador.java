public class mtirador {
    public static void main(String[] args) {
        //https://www.java.com/es/

        /*diferente comentario para varias lineas
         * 
         * ......
         */
        /**
         * Comentarios de documentación
         */

         /*Declaracion de variables y constante */
        int unidades =12;
        final float precio = 9.99f;


        /*Crea variables representando todos los tipos de datos primitivos
        *   del lenguaje (cadenas de texto, enteros, booleanos...).*/

        int num=5;
        short snum=9;
        long lnum= 3;
        double dnum=3.4;
        float fnum=5.4f;
        boolean condi=true;
        byte bnum=2;
        char a= 'b';

        //imprimir hola + lenguaje

        String palabra="Java";

        System.out.println("¡Hola,"+ palabra +"!");
    }    
}
