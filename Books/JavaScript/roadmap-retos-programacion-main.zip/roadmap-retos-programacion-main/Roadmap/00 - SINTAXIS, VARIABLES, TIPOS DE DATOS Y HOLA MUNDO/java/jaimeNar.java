public class jaimeNar {
  public static void main(String args[]) {
    // URL del sitio web oficial
		/**
		 * https://www.java.com
		 **/

		// Diferentes sintáxis para crear comentarios
		// Comentario de una sola línea

		/*
		 * Comentario de varias líneas
		 */

		/**
		 * Otro comentario de varias líneas
		 **/

		int variable; // Variable

		final int constant; // Constante

		// Variables que representan los tipos de datos primitivos
		byte by = 127;
		short num_sh = 32767;
		int num = 234567834;
		long num_long = 456546465L;
		float num_float = 1.5f;
		double num_double = 3.7;
		char character = 'A';
		boolean bool = true;

		// Imprime por terminal el texto: "¡Hola, [y el nombre de tu lenguaje]!"
		System.out.println("¡Hola, Java!");
  }
}

