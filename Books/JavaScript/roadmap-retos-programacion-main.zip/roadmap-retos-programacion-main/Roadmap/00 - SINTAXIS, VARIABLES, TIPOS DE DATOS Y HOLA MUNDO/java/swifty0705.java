package com.mouredev.retosprogramacion.roadmap.cero;

public class swifty0705 {
    // URL oficial: https://www.java.com/es/
    // JDK: https://www.oracle.com/co/java/technologies/downloads/
    // IDE: https://www.jetbrains.com/es-es/idea/

    public static void main(String[] args) {
        // comentario de una linea
        /*
         * comentario de varias lineas
         */

        /**
         *
         *  JavaDocs
         *
         * */

        // variables
        byte b = 100;
        short s = 10000;
        int i = 100000;
        long l = 100000L;
        float f = 10000.0f;
        double d = 10000.0d;
        char c = 'A';
        String usuario = "Swifty0705";

        var integer = 100;

        //constante
        final double PI = 3.141516;

        System.out.println("Hola Java! soy "+usuario);

    }
}
