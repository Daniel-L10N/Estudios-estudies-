public class rumacar05 {

    // https://www.java.com/es/

    // Comentario en una sola línea
    /*
     Comentario 
     en varias 
     lineas
    */
    public static void main(String[] args) {
        String saludo = "Hola"; // Variable
        final String LENGUAJE = "Java"; // Constante

        // Variables primitivas
        byte a = 10;
        short b = 100;
        int c = 1000;
        long d = 10000L;
        double e = 100000.0;
        float f = 1000000.0f;
        char g = 'a';
        boolean h = true;

        System.out.println("¡" + saludo + ", " + LENGUAJE + "!");
    }
}