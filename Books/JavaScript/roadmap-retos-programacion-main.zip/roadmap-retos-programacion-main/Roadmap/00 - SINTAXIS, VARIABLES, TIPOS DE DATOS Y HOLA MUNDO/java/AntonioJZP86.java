public class AntonioJZP86 {
    // https://www.java.com/es/
    // Esto es un comentario de una línea

    /*
     * Esto es un comentarrio en varias líneas
     */

    public static void main(String[] args){
        String variable= "¡Hola, ";
        final String constante = "Java!";
        char letra = 'A';

        byte edad = 123;
        short altura = 12345;
        int cantidad = 1234567890;
        long largo = 1234567890123456789L;

        float flotante = 11.11f;
        double doble = 11.1;

        boolean esVerdadero = true;

        System.out.println(variable + constante);

    }
}

