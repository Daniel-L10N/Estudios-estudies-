
// https://www.java.com

public class oixild {
    public static void main(String[] args) {

        // Comentario de una sola línea

        /*
         * Comentario en
         * varias líneas
         */

        // variable y constante
        String lenguajeRetos = "Esto es una cadena de texto (String) ";
        final String java = "Java";

        // Variables representando todos los tipos de datos primitivos del lenguaje
        byte miByte = 1;
        short miShort = 55;
        int miInt = 7414;
        long miLong = 831823821;
        float miFloat = 1.1f;
        double miDouble = 5.5;
        char miChar = 'a';
        boolean miBoolean = true;

        System.out.println("¡Hola," + java + "!");
    }
}