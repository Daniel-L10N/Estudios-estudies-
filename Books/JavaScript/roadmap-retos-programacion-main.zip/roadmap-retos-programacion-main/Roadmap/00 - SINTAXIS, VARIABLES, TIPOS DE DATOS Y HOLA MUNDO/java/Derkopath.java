public class Derkopath{
    public static void  main (String[] args) {

        /*
        Web oficial:
        https://www.java.com/es/

        Web de aprendizaje:
        https://dev.java/learn/
        */

        // - Comentarios:

        // Comentario en una línea

        /* Comentario en
            múltiples líneas.
         */

        // - Declara una variable:

        int variable1 = 0;

        // - Declara una constante

        static final int CONSTANTE = "constante";

        // - Tipos de datos primitivos:
        byte tipo1 = 0;
        short tipo2 = 0;
        int tipo3 = 0;
        long tipo4 = 0L;
        float tipo5 = 0.0f;
        double tipo6 = 0.0d;
        char tipo7 = 'a';
        String tipo8 = "Hola mundo!";
        boolean tipo9 = true;

        // - Imprimir por terminal:

        System.out.println("¡Hola, Java!");
    }
}







