/**
 * Devknn
 */
public class Devknn {

    public static void main(String[] args) {
        // https://www.java.com/es/

        /*
         * Comentario de 
         * varias 
         * lineas
         */
      
        var name = "java";
        //Variable constante
        final String cadenaTexto = "Java";
        int numeroEntero = 5;
        boolean booleano = false;

        System.out.println(String.format("Hola %s", cadenaTexto));
    }
}