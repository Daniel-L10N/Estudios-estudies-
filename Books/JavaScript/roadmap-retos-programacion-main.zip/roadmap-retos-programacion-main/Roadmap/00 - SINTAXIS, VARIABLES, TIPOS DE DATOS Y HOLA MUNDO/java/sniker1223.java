//https://www.oracle.com/mx/java/

/** Document 
 * Comment */

//Single Line Comment

/* Multiple
Line 
Comment */

public class sniker1223 {

  public static final String FIRST_NAME = "Sara";
  public static void main(String[] args){

    //primitive Data types
    boolean var1 = true;
    char var2 = 'A';
    byte var3 = 1;
    short var4 = 1;
    int var5 = 1;
    long var6 = 1l;
    float var7 = 1.1f;
    double var8 = 1.1d;
    
    System.out.print("¡Hola, JAVA!");
  }
}
