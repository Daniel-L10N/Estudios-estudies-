public class xurxogz {
    public static void main(String[] args) {
        // #00 SINTAXIS, VARIABLES, TIPOS DE DATOS Y HOLA MUNDO

        // URL oficial de Java: https://www.java.com/es/
        /*
         * Comentario
         * De
         * Varias
         * Lineas
         */

        String myVar = "Variable";
        final String myConst = "Constante";

        byte myByte = 10;
        short myShort = 20;
        int myInt = 10000;
        long myLong = 10200;
        char myChar = 'a';
        boolean myBool = false;

        System.out.println("¡Hola, Java!");

    }
}