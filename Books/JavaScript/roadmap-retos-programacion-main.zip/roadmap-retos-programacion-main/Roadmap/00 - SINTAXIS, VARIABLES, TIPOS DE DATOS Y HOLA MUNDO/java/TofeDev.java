public class TofeDev {
    public static void main(String[] args) {

        // Sitio oficial de Java: https://www.oracle.com/ar/java/
        
        // Comentario de una sola linea
        
        /* Comentario de
         * varias lineas
        */

        // Variable y constante:
        
        var variable = "Hola Mundo";
        final String constante = "Hola Roadmap 2024";
        
        //Datos Primitivos
        
        byte uno = 12;
        short dos = 1542;
        int tres = 35410;
        long cuatro = 486415444;
        float cinco = 1.84f;
        double seis = 5.16d;
        boolean siete = true;
        char ocho = 'a';
        
        System.out.println("¡Hola, Java!");

    }
        
}
