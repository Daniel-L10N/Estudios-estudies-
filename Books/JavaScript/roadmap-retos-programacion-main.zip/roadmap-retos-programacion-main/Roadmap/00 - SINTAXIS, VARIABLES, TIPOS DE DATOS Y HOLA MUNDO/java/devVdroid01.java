// Aquí se crea un package "retos_de_programacion"
package retos_de_programacion;

public class devVdroid01 {
	public static void main(String[] args) {
		// El sitio oficial de Java es:: https://www.java.com/es/

        // Esto es un comentario de una sola línea

        /* Esto es un comentario de una 
        o más líneas (multilínea)*/

        /** Esto es un comentario para javadoc (para documentar con esta herramienta) */
	
        int variable_edad;
        final int NUMERO_CABEZA = 1;
        // Tipos de datos primitivos
        byte v_byte;
        short v_short;
        int v_int;
        long v_long;
        float v_float;
        double v_double;
        char v_char;
        String v_string = "Java";
        boolean v_boolean;

        System.out.println("¡Hola, " + v_string + "!");
	}

}
