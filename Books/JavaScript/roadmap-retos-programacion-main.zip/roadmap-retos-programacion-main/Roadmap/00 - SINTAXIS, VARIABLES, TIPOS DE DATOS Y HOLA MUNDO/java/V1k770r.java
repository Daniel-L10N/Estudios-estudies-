public class Main {
    public static void main(String[] args) {
        //  https://www.java.com
        /*
            "https://www.java.com/";
            "https://www.java.com/";
            "https://www.java.com/";
        */
        String direccion = "https://www.java.com/";
        final String DIRECCION2 = "https://retosdeprogramacion.com/roadmap/#last";

        char b = 'l';
        byte a = 2;
        int número = 10_000;
        long numero2 = 100_000_000;
        double nummero4 = 512_123_454;
        float numero3 = 1.5F;
        boolean valor = true;

        System.out.println("Hola Java!!!");
    }
}
