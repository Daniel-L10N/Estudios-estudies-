// DeathbatO
public class Reto{

    public static void main(String[] args) {
        //En un comentario de linea colocamos el sitio oficial de Java
        //https://www.java.com/es/

        //Esto es un comentario en una linea

        /*Esto es un comentario de varias lineas
        usando el asterizco y la barra inclinada*/

        int varInt = 90;
        String varString = "Holaaa";
        double varDouble = 2.25;
        boolean varBool = true;
        String Leng = "Java";

        System.out.println("Tipos de variables y ejemplos: ");
        System.out.println("Int: "+varInt+"\nString: "+varString+"\nDouble: "+varDouble+"\nBoolean: "+varBool);
        System.out.println("Hola, "+Leng);

    }
}