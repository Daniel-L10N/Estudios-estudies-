public class CristianMR87 {
    public static void main(String[] args) {
        
        // https://www.java.com/es/

        //Comentario en una linea
        /*
         * Comentario
         * en
         * varias
         * lineas
         */

        //Crear una variable:
        int miVariable = 1234;
        final int constante = 1;

        //Variables con tipos de datos primitivos
        int valorInt = 12;
        double valorDouble = 12.3;
        float valorFloat = 12.4f;
        String valorString = "JAVA";
        char valorChar = 'A';
        boolean valorBoolean = true;

        System.out.println("Hola, "+valorString);



    }
}
