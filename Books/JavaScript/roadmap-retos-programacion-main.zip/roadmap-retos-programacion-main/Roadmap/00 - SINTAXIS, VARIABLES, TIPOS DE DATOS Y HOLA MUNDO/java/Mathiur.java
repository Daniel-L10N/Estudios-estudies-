// Crea un comentario en el código y coloca la URL del sitio web oficial del lenguaje de programación que has seleccionado
// https://www.java.com/es/
// Esto es un comentario de una linea
/*Esto es un comentario
 * multilinea
 */

public class Mathiur { // Renombrado para empezar con mayúscula
    public static void main(String[] args) {
        // DATOS PRIMITIVOS
        int Entero = 2; //Entero
        float Flotante = 15.4f; //Float
        double Decimal = 18.4; //Decimal
        boolean Booleano = true; //Booleano true o false
        char Caracter = 'M'; //Caracter
        String Texto = "Mathiur"; //Cadena de texto
        //Constante
        final int Constante = 18; //Constante

        //Imprime por terminal el texto: "¡Hola, [y el nombre de tu lenguaje]!"
        String Lenguaje = "Java";
        System.out.println("¡Hola, " + Lenguaje + " !");
    }
}
