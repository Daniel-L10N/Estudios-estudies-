public class FrancoFMV{
    //sitio oficial de https://dev.java/
    /*
     * Este es un comentario
     * en varias
     * lineas
     */
    /*Este tambien
     es un comentario
     en varias lineas
     */
    public static void main(String[] args) {
        String language = "Java"; // Variable
        
        //Tipo de datos primitivos: byte, short, int, long, float, double, char, boolean
        int myInt = 1;
        double myDouble = 1.5;
        float myFloat = 1.5f;
        char myChar = 'C';
        boolean bTrue = true;
        boolean bFalse = false;
        byte  myByte = (byte)9;
        short myShort = (short)27001;
        long myLong = 8640000000001L;

        final int constant = 6; //Constante

        System.out.println("¡Hola " + language + "!");
    }
}