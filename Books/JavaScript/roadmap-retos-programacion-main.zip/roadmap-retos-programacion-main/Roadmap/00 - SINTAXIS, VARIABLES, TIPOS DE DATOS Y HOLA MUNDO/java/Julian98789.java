package MauroDevRetos;

//https://www.oracle.com/java/

/*
 * https://www.oracle.com/java/
 */

/**
 * https://www.oracle.com/java/
 */
public class julian98789 {

    int numero;
    final int numeros = 4;

    byte unByte = 127; // Rango: -128 a 127
    short unShort = 32767; // Rango: -32,768 a 32,767
    int unInt = 2147483647; // Rango: -2^31 a 2^31-1
    long unLong = 9223372036854775807l; // Rango: -2^63 a 2^63-1

    // Punto flotante
    float unFloat = 3.14f; // Precisión simple
    double unDouble = 3.141592653589793; // Precisión doble

    // Carácter
    char unChar = 'A'; // Almacena un solo carácter Unicode

    // Booleano
    boolean unBoolean = true; // Puede ser true o false

    public static void main(String[] args) {
        System.out.println("Hola, Java");
    }

}
