// #00 - Sintaxis, variables, tipos de datos y hola mundo

// www.java.com

public class Qv1ko {

    public static void main (String[] args) {
        
        // Comment

        /*
         * Comment
         */

        int var1 = 1;
        final int VAR2 = 2;

        String str1 = "Java";
        char var3 = 'c';
        int var4 = 4;
        float var5 = 5.5f;
        double var6 = 6.6;
        boolean bool = true;

        System.out.println("¡Hola, " + str1 + "!");

    }

}
