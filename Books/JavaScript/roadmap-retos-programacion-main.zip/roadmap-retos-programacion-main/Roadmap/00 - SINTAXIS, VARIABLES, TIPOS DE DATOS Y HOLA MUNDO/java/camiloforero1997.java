// Comentario en una sola linea

//Aqui en en el siguiente link podremos encontrar todo lo relacionado con Java https://www.java.com/

/*Comentario
 * de varias
 * lineas
 */

public class Camiloforero1997{

    Public static void main (String[] args){

        //Creando una variable definida y no definida

        String variableDefinida = "Tengo un valor";
        String variableNoDefinida;

        //Constantes

        final String SOYUNACONSTANTE = "Constante";

        //Datos primitivos

        int datoInt = 5000;
        float datoFloat = 3,892f;
        double datoDouble = 3,127128231731D;
        char datoChar = 122;
        long datoLong =829L;
        short datoShort = 238;
        byte datoByte = 2;
        boolean datoBoolean = true;
        String DatoString = "Soy string";

        System.out.println("Hola Java");

    }

}
