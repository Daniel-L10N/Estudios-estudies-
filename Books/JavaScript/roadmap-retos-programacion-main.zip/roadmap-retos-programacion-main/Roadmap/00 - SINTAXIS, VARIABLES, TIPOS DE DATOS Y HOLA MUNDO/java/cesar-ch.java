﻿// URL: https://www.java.com/es/

// Este es un comentario de una sola línea

/*
 * Este es un comentario 
 * de varias líneas
 */


public class cesarch {
    public static void main(String[] args) {
    
        // Variable y constante
        String lenguaje = "Java";
        final int YEAR = 2024;
        
        // Tipos de datos primitivos
        byte numeroByte = 127;
        short numeroShort = 32767;
        int numeroInt = 2147483647;
        long numeroLong = 9223372036854775807L;
        float numeroFloat = 3.14f;
        double numeroDouble = 3.14;
        boolean booleano = true;
        char caracter = 'a';
        String cadena = "Hola mundo";

        System.out.print("¡Hola, " + lenguaje + "!");

    }
    
}