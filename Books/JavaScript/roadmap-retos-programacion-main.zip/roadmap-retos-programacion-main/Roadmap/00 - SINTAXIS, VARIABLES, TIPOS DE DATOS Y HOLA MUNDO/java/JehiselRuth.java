//Sitio oficial del lenguaje de Java url: https://www.java.com/es/

/*En Java puedes comentar utilizando / y asterisco * cerrando finalmente con el asterisco y la barra, nuevamente */
//También puedes usar doble barra si lo que quieres comentar se encuentra en una misma línea


public class JehiselRuth {
    
    //Variable 
    int variableNumber = 9;
    //Constante
    final int MY_AGE = 38;

    //Tipos de datos primitivos
    int fingers = 5;
    float weight = 53.4f;
    double average = 4.95;
    char character = 'J';
    boolean isComplete = true;
    String myLanguaje = "Jehisel";
    
    public static void main(String[] args) {
        String myLanguaje = "Java";
        System.out.println("¡Hola, "+ myLanguaje + "!");
    }

}
