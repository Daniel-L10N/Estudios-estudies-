public class Ldre3 {
    // Creacion de constantes y variables

    private int variable = 5;
    private final char CONSTANTE = 'A';
    public static void main(String[] args) {
        // https://www.java.com/es/

        // Comentario de una linea

        /*
        Comentario de
        Varias lineas
         */

        /**
         * Comentario en javadoc
         */

        byte mibyte = 5;
        boolean booleano = true;
        short numero = 4;
        long largo = 486498468;
        int entero = 5;
        char letra = 'a';
        double decimal = 5.5;
        float flotante = 5.6F;

        System.out.println("¡Hola, Java!");


    }
}
