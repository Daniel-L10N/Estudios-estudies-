// #00 SINTAXIS, VARIABLES, TIPOS DE DATOS Y HOLA MUNDO
// URL del sitio web oficial de Java: https://www.java.com/es/
// Comentario de una línea
/*
 * Comentario 
 * en
 * bloque 
 */

public class reneguzman7 {
    public static void main(String[] args) {
        // Creación de una variable
         String miVariable = "Hola";
         // Creación de una constante
         final double PI = 3.1416;

        byte  datoTipoByte; 
		short datoTipoShort; 
		int datoTipoEntero; 
		long datoTipoLargo; 
		float datoTipoFloat; 
		double datoTipoDouble;
		char datoTipoChar;
		boolean datoTipoBoolean; 
		String datoTipoString; 

        System.out.println("Hola, Java!");
    }
 }