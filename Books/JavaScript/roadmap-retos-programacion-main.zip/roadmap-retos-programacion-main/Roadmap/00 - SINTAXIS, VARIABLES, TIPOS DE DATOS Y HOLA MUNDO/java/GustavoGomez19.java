public class GustavoGomez19 {
    public static void main(String[] args){
        //Punto 1: Web oficial de Java: https://www.java.com/es/

        //Punto 2: Este es un comentario de una sola línea

        /*Punto 2: Este es
        * un comentario
        * de varias líneas*/

        //Punto 3: Creación de una variable (Tipo cadena de texto)
        String saludo = "¡Hola RoadMap 2024";
        //Punto 3: Creación de constante (final)
        final int edad = 31;

        //Punto 4: Creación de variables con todos los tipos de datos primitivos
        byte numByte = 1;
        short numShort = 10;
        int numInt = 100;
        long numLong = 1000;
        float numFloat = 10000.0F;
        double numDouble = 100000.0;
        char caracter = 'G';
        boolean boolT = true;
        boolean boolF = false;
        String apellido = "Gomez";

        System.out.println("¡Hola, Java!");

    }
}
