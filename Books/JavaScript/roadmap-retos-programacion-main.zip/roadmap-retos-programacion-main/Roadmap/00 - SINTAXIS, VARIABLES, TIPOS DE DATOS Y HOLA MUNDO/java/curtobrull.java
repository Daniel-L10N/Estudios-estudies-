public class curtobrull {
    public static void main(String[] args) {

        // Web Oficial: https://www.java.com

        // Comentario 1 línea.

        /*
         * Comentario multilinea.
         */

        String CONSTANTE = "Java";

        boolean bool = false;
        char character = 'a';
        byte numByte = 0;
        short numShort = 0;
        int integer = 0;
        double numDouble = 0.0;
        float numFloat = 0.0f;
        long numLong = 0L;

        System.out.println("¡Hola, " + CONSTANTE + "!");
    }

}