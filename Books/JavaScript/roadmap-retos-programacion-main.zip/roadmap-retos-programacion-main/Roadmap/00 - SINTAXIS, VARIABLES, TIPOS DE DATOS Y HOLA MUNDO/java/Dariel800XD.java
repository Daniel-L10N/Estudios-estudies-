public class Dariel800XD {
    
    public static void main(String[] args) {
        
        //https://www.java.com

        //esta es una forma de comentar en java
        /*Esta es para varias lineas
        de codigo*/ 


        //Constante:
        final int constante;


        //Variables:
        byte var = 127;
        short var2 = 20000;
        int var3 = 2000;
        long var4 = 400000;
        float var5 = 2;
        double var6 = 3.14;
        boolean var7 = true;
        char var8 = 'D';
        String var9 = "Hola";

        System.out.println("Hola, Java");

    }
}
