public class marce1084 {
    public static void main(String[] args) {
        //https://www.java.com/es/

        //Esto es un comentario simple

        /*Esto tambien es un
        * comentario de
        * varias lineas
        */

        String nombre = "Ariel"; //Variable

        int valor = 253; //Constante

        //Datos primitivos
        int num1 = 23784;
        double num2 = 56.54;
        float num3 = 23.4f;
        byte num4 = 12;
        short num5 = 124;
        long num6 = 891293;
        char letra7 = 'A';
        boolean valor8 = true;
        String frase9 = "Hola a todos";

        System.out.println("¡Hola, Java!");

    }
}
