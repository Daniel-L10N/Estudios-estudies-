public class Ejercicio00 {
    public static void main(String[] args) {
        
        // Pagina oficial: https://www.java.com/es/

        // Esto es un comentario de una sola linea

        /*
         * Esto es un comentario 
         * multilinea
         */
     
         String mi_variable = " java¡"; // Declarando una variable

         final float pi = 3.1416f;  // Declarando una constante

         // Tipos de datos 

         int mi_entero = 7; // Variable entera: int (numeros enteros)

         float mi_flotante = 7.5f; // Variable flotante: float (numeros decimales)

         boolean mi_booleano = true; // Variable booleana: bool (true o false)

         String mi_cadena = "mi cadena"; // Variable string: str (cualquier texto entre comillas dobles)

         char mi_caracter = '5'; // Variable tipo caracter: char (una letra o numeros entre comillas simples )

        System.out.println("!Hola" + mi_variable);
    }
}
