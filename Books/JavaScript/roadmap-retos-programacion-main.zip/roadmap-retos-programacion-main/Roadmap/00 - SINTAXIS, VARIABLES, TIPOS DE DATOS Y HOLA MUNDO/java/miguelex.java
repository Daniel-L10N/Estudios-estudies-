public class miguelex {

    // Documetación en https://www.java.com/
    public static void main(String[] args) {
        // Comentario en una sola linea

        /*
         * Comentario
         * en varias
         * lineas
         */

        // Variables y constantes
        String lenguaje = "Java";
        final String constante = "Soy Dev";

        // Tipos primitivos
        byte diasMes = 31;
        short diasLustro = (12 * 31) * 5;
        int velocidadLuz = 299792458;
        long anioLuz = velocidadLuz * 365;
        float pi = 3.1415926535f;
        double e = 2.718281828459045235360;
        char letraA = 'a';
        char letraANumerico = 61;
        boolean verdadero = true;
        boolean falso = false;

        // Salida por consola
        System.out.println("¡Hola, " + lenguaje + "!");

    }

}