public class Karolle {
    public static void main(String[] args) {
        // Java official website: https://www.java.com/

        // This is a single-line comment

        /* This is a 
        comment that 
        spans multiple
        lines */

        // Declaration of a variable
        String myVariable = "Hola";

        // Declaration of a constant
        final String myLanguage = "Java";

        // Variables representing primitive data types
        byte myByte = -128;
        short myShort = 32767;
        int myNum = 5;               
        long myLongnum = 922337203685477807L;
        float myFloatNum = 5.99f;    
        char myLetter = 'K';         
        double myDoubleNum = 3.1415926535;
        boolean myBool = true;            

        System.out.println("¡" + myVariable + ", " + myLanguage + "!");
    }
}