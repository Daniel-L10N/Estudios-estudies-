//Official website: https://www.oracle.com/co/java

//One line commentary

/*
 *Multi-line commentary
 */

public class JuanWills_00 {
    public static void main(String[] args){

        //Variable 
        int var;
        //Constant
        final int cons;

        //Primitive types
        byte Byte;
        short Short;
        int Integer;
        long Long;
        boolean Boolean;
        char Char;
        String string; //Not a primitive type but an object

        //Printing
        System.out.println("Hola Java!");

    }
}
