package Retos;

// Sitio oficial https://www.java.com/

// Comentario en linea

/*
    Comentario para
    varias lineas
    @autor: JcKnot
*/

        
public class JcKnot {
    public static void main(String[] args) {
        // variable
        String variable = "variable";
        
        // constante
        final String constante = "constante";
        
        // tipos de datos primitivos
        byte tipoByte = 20;
        short tipoShort = 100;
        int tipoInt = 1000;
        long tipoLong = 10000;
        float tipoFloat = 3.14f;
        double tipoDouble = 3.14;
        boolean tipoBoolean = true;
        char caracter = 'a';
        String jv = "Java";
        
        System.out.println("¡Hola, " + jv + "!");
    }
}