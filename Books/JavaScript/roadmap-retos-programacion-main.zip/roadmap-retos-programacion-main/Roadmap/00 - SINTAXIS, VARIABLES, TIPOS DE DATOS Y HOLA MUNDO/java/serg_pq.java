public class serg_pq {

    public static void main(String[] args) {
        // Web oficial: www.java.com

        // Comentario de una sola linea

        /*
        Comentario de
        multiples lineas
         */


        String username = "Sergio"; // Declaración de una Variable
        final String country = "Colombia"; // Declaración de una Constante


        // Tipos de datos primitivos
        // Datos enteros
        byte myByte = 123;
        short myShort = 12345;
        int myInt = 1234567890;
        long myLong = 1234567890987654321L;

        // Datos flotantes
        float myFloat = 1.23f;
        double myDouble = 1.23456;

        // Dato caracter
        char myChar = 'A';

        // Dato booleano
        boolean myBoolean = true;


        // Imprimir texto
        System.out.println("¡Hola, Java!");
    }
}
