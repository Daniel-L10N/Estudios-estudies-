public class EspinoLeandroo {

    /**
     * Este es un comentario de documentación.
     * Se utiliza para generar documentación automáticamente.
     * @param args Descripción del parámetro args.
     */
    public static void main(String[] args) {
        // https://www.java.com/es/
        // Esto es un comentario de una línea

        /*
        * Esto es un comentario
        * que abarca múltiples líneas.
        * Puedes escribir varias líneas aquí.
        */

        final String ejercicio = "#00 SINTAXIS, VARIABLES, TIPOS DE DATOS Y HOLA MUNDO";
        String lenguaje = "java";
        
        byte edad = 27;
        short distancia = 10000;
        int cantidad = 1000000;
        long poblacionMundial = 7800000000L;
        
        float altura  = 1.8f;
        double pi = 3.141592653589793;
        
        char letra = 'A';

        boolean esMayorDeEdad = true;
        
        System.out.println("¡Hoola, Java!");
    }
}