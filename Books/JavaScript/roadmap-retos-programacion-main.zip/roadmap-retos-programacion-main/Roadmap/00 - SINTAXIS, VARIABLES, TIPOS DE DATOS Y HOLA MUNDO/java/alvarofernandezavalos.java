public class alvarofernandezavalos {
  // this is a comment
  /*
    https://www.oracle.com/es/
    https://www.java.com/es/
   */
  // constante
  private static final String CONSTANTE = "CONSTANTE";
  public static void main (String[] args) {
    // variables
    boolean bVar1  = true;
    float fVar2    = 6.9f;
    int fVar3      = 2;
    char fVar4     = 'H';
    byte fVar5     = 0;
    short fVar6    = 1;
    long fVar7     = 33L;
    double fVar8   = 1.23d;

    System.out.println("Hola, Java");
  }
}