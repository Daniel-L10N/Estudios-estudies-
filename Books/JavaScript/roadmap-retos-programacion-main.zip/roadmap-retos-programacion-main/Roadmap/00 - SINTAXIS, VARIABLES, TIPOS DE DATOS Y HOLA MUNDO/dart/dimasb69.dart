// URL del Lenguaje usado: https://dart.dev

// Sintaxis para crear una liena de comentario

/* Sintaxis para un comentarios
de multiples lineas */

var variable = 'esto es una variable '; 

const constante = 3.141516; //Constante forma 1

final constante2 = "Esto tambien es constante"; //es otra forma de declarar una cosntante


String string = "Hola,"+' Dart'; //se puede usar comillas simples ' o triple """ ó ''' para multiples lineas

int entero = 10; //Numeros enteros

double decimal = 10.0; //Numeros con Decimales

bool boleano = true; //True ó False



void main() {
 
  print(string);// Para imprimir por terminal

}

//Es igual para Flutter