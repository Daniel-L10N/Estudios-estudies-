void main() {
  //Pagina de Dart https://dart.dev/

  //Comentario en una linea

  /*
    Comentario en varias
    varias
    varias
  */

  var variable = "Si";
  const constante = 10.23;

  String cadena = "Hola Dart";
  int entero = 8;
  bool booleano = true;
  double dobleflotante = 2.891273;

  //Imprimo las variables para evitar los warnings de variables en desuso
  print("Variable: $variable");
  print("Constante: $constante");
  print("String: $cadena");
  print("Entero: $entero");
  print("Boolean: $booleano");
  print("Flotante: $dobleflotante");

  print("Hola, Dart!!");
}
