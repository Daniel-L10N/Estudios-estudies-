//https://dart.dev/ //

/*
Esto es
un comentario
de multiples
lineas

*/

/// esto es un comentario
///
/// de documentación
///

//tipos de variables y constantes
var name = "evelyn";

String username = "evelyn nobile";

final age = 30;

const lenguage = "Dart";



//tipos de datos
int entero = 10;
double decimal = 10.5;
bool boleano = true;

var list = [1, 2, 3, 4, 5];

var map = {
  "name": "evelyn",
  "age": 30
};

//imprimir en terminal
void main() {
  print("¡Hola, Dart!");
}
