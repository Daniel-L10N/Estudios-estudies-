// Documentación en https://dart.dev

// Comentario en una linea

/* Comentario
de varias lineas */

void main() {
  //Declaracion de una variable
  var lenguaje = 'Dart';

  // Declaracion de una constante
  const PI = 3.14;

  // Tipos primitivos de datos
  int unNumero = 10;
  double unDecimal = 0.5;
  bool esBooleano = true;
  String cadena = "Soy una cadena";

  // Salida por consola
  print('Hello $lenguaje!');
}